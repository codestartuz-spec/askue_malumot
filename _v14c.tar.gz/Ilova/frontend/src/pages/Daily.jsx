// «Kunlik topshiriq» — alohida bo'lim: 5 ta Excel fayl → jadvallar va nomma-nom topshiriq fayli.
// Tablar: Fayl yuklash · Arxiv · Sozlamalar (boshqa bo'limlardan mustaqil).
import { useCallback, useEffect, useRef, useState } from 'react'
import { Link, useSearchParams } from 'react-router-dom'
import { Archive, ArrowDown, ArrowUp, CheckCircle2, ClipboardList, Clock, Download, Eye, FileArchive, FileSpreadsheet, Image as ImageIcon, Loader2, Megaphone, Package, RefreshCw, Save, Send, Settings2, Trash2, UploadCloud, X, AlertTriangle, MailCheck } from 'lucide-react'
import { api, download, uploadForm } from '../api'
import { useAuth } from '../auth'
import { ChatTable, Confirm, Empty, Modal, Spinner, useToast } from '../ui'
import { dmy, dt, num } from '../fmt'

const KINDS = [
  { k: 'area', label: 'AreaInformationReport', hint: 'area' },
  { k: 'status', label: 'CommissioningStatus', hint: 'commissioning' },
  { k: 'direct', label: 'DirectMeter', hint: 'directmeter' },
  { k: 'nometer', label: 'NoMeterData', hint: 'nometer' },
  { k: 'online', label: 'Online_Device_Monitoring', hint: 'online_device' },
]
const kindOf = (name = '') => {
  const n = name.toLowerCase().replace(/[^a-z0-9_]/g, '')
  return KINDS.find((x) => n.includes(x.hint))?.k || ''
}
const GROUPS = [{ k: 't1', t: 't1_title', note: 'Konsentratorlar jadvali (rasm)' }, { k: 't2', t: 't2_title', note: 'Aloqadan chiqib ketgan hisoblagichlar jadvali (rasm)' }, { k: 'task', t: 'task_title', note: '7 ta nomma-nom Excel fayl' }]
const CATS = [['aholi', 'Aholi'], ['ulgurji', 'Ulgurji'], ['balans', 'Balans']]
const mb = (b) => (b >= 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`)

/* ------------------------------------------------------------------ jadval (skrinshotdagi dizayn) */
function DailyTable({ tb, region, date }) {
  const cls = (h) => [...(h.c || '').split(' ').filter(Boolean).map((x) => 'h-' + x), h.rot && 'rot', h.it && 'it'].filter(Boolean).join(' ')
  return (
    <div className="card tcard daily-card">
      <div className="daily-top"><span>Hudud nomi: <b>{region}</b></span><b>{dmy(date)}</b></div>
      <div className="tbl-scroll">
        <table className={`dyn-table daily-table dt-${tb.key}`}>
          <thead>{tb.head.map((hr, i) => (
            <tr key={i}>{hr.map((h, j) => <th key={j} rowSpan={h.rs} colSpan={h.cs} className={cls(h)}><span>{h.l}</span></th>)}</tr>))}</thead>
          <tbody>
            <tr className="total"><td className="name">Jami</td>{tb.cols.map((c) => <td key={c.k} className={`n ${c.c ? 'c-' + c.c : ''}`}>{num(tb.total[c.k]) === '0' ? '' : num(tb.total[c.k])}</td>)}</tr>
            {tb.rows.map((r) => (
              <tr key={r.name}><td className="name">{r.name}</td>
                {tb.cols.map((c) => <td key={c.k} className={`n ${c.c ? 'c-' + c.c : ''} ${c.cream ? 'cream' : ''}`}>{r.v[c.k] ? num(r.v[c.k]) : ''}</td>)}</tr>))}
          </tbody>
        </table>
      </div>
    </div>
  )
}

/* ------------------------------------------------------------------ Telegramga yuborish */
/* Yuborish jurnali: «belgi \t kalitlar \t kanal \t xato» (kalitlar: img1+img2) */
const parseLog = (log = '') => log.split('\n').filter(Boolean).map((l) => { const [m, k, c, e] = l.split('\t'); return { m, k, c, e } })
const mmss = (ms) => `${String(Math.floor(ms / 60000)).padStart(2, '0')}:${String(Math.floor(ms / 1000) % 60).padStart(2, '0')}`

function SendModal({ b, defaults, onClose }) {
  const toast = useToast()
  const outs = b.outs || []
  const [chats, setChats] = useState(null)
  const [files, setFiles] = useState(new Set(outs.filter((o) => o.default).map((o) => o.k)))
  const [sel, setSel] = useState(null)
  const [ack, setAck] = useState(false)
  const [job, setJob] = useState(null)
  const [plan, setPlan] = useState(null)       // { units: [['img1','img2'], ['off'], ...], chats: [title, ...] }
  const [busy, setBusy] = useState(false)
  const [t0, setT0] = useState(0)
  const [now, setNow] = useState(0)
  const timer = useRef(null)
  useEffect(() => {
    api.get('/daily/chats').then((c) => { setChats(c); setSel(new Set(c.filter((x) => GROUPS.some((g) => (defaults[g.k] || []).includes(x.id))).map((x) => x.id))) })
      .catch((e) => { toast(e.message, 'err'); setChats([]); setSel(new Set()) })
    return () => clearInterval(timer.current)
  }, [])
  const flip = (setter, k) => setter((s) => { const n = new Set(s); n.has(k) ? n.delete(k) : n.add(k); return n })
  const byKey = Object.fromEntries(outs.map((o) => [o.k, o]))
  const unitTitle = (u) => (u.length > 1 ? `Jadval rasmlari — ${u.length} ta (albom)` : byKey[u[0]]?.title || u[0])
  const start = async (fileList, chatIds) => {
    setBusy(true)
    try {
      const ordered = outs.map((o) => o.k).filter((k) => fileList.includes(k))
      const pics = ordered.filter((k) => k.startsWith('img'))
      const units = [...(pics.length > 1 ? [pics] : []), ...ordered.filter((k) => !pics.includes(k) || pics.length === 1).map((k) => [k])]
      const r = await api.post(`/daily/${b.id}/send`, { files: ordered, chat_ids: chatIds, ack })
      setPlan({ units, chats: (chats || []).filter((c) => chatIds.includes(c.id)).map((c) => c.title) })
      setJob({ status: 'running', progress: 0, log: '' })
      setT0(Date.now()); setNow(Date.now())
      clearInterval(timer.current)
      timer.current = setInterval(async () => {
        setNow(Date.now())
        try {
          const j = await api.get(`/reports/send/${r.id}`)
          setJob(j)
          if (j.status !== 'running') {
            clearInterval(timer.current); setBusy(false)
            toast(j.status === 'done' ? 'Yuborish yakunlandi' : 'Yuborishda xatolar bor', j.status === 'done' ? undefined : 'err')
          }
        } catch { /* keyingi urinishda */ }
      }, 1000)
    } catch (e) { toast(e.message, 'err'); setBusy(false) }
  }
  // jurnaldan: har bir (qadam, kanal) holati
  const ev = parseLog(job?.log)
  const stateOf = (u, c) => {
    const k = u.join('+')
    const hit = ev.filter((e) => e.k === k && (e.c === c || e.c === '*')).pop()
    if (hit?.m === '✓') return { s: 'ok' }
    if (hit?.m === '✗') return { s: 'bad', e: hit.e }
    return { s: ev.some((e) => e.m === '…' && e.k === k) ? 'run' : 'wait' }
  }
  const total = plan ? plan.units.length * plan.chats.length : 0
  const cells = plan ? plan.units.flatMap((u) => plan.chats.map((c) => ({ u, c, ...stateOf(u, c) }))) : []
  const nOk = cells.filter((x) => x.s === 'ok').length
  const nBad = cells.filter((x) => x.s === 'bad').length
  const fin = job && job.status !== 'running'
  const curUnit = plan?.units.find((u) => plan.chats.some((c) => stateOf(u, c).s === 'run' || stateOf(u, c).s === 'wait'))
  const retry = () => {
    const bad = cells.filter((x) => x.s === 'bad')
    const fl = [...new Set(bad.flatMap((x) => x.u))]
    const ids = (chats || []).filter((c) => bad.some((x) => x.c === c.title)).map((c) => c.id)
    if (fl.length && ids.length) start(fl, ids)
  }
  const pct = job ? Math.min(100, Math.max(job.progress, 0)) : 0
  return (
    <Modal wide icon={Send} title={`Telegramga yuborish — ${dmy(b.date)}`} onClose={onClose}
      footer={<><div className="foot-info">{plan ? (fin ? `${nOk} ta yuborildi${nBad ? `, ${nBad} ta xato` : ''}` : `Yuborilmoqda: ${nOk + nBad} / ${total}`) : `${files.size} ta fayl${sel?.size ? ` → ${sel.size} ta kanal` : ''}`}</div>
        <button className="btn ghost" onClick={onClose}>{busy ? 'Yopish (fonda davom etadi)' : 'Yopish'}</button>
        {plan && fin && <button className="btn ghost" onClick={() => { setPlan(null); setJob(null) }}><RefreshCw size={16} />Yangi yuborish</button>}
        {plan && fin && nBad > 0 && <button className="btn primary" onClick={retry}><RefreshCw size={16} />Xatolarni qayta yuborish</button>}
        {!plan && <button className="btn primary" disabled={busy || !files.size || !sel?.size} onClick={() => start(outs.map((o) => o.k).filter((k) => files.has(k)), [...sel])}><Send size={16} />Yuborish</button>}</>}>
      {plan ? (
        <div className="sp-wrap">
          <div className={`sp-head ${fin ? (nBad ? 'bad' : 'ok') : ''}`}>
            <div className="sp-pct">{fin && !nBad ? <CheckCircle2 size={30} /> : fin ? <AlertTriangle size={30} /> : <Loader2 size={30} className="spin" />}<b>{Math.round(fin && job.status === 'done' ? 100 : pct)}%</b></div>
            <div className="sp-info">
              <b>{fin ? (nBad ? 'Yuborish yakunlandi — xatolar bor' : 'Hammasi yuborildi') : curUnit ? `Hozir: ${unitTitle(curUnit)}` : 'Boshlanmoqda…'}</b>
              <small>{nOk} / {total} qadam bajarildi{nBad ? ` · ${nBad} ta xato` : ''} · {plan.chats.length} ta kanal · {mmss(Math.max(now - t0, 0))}</small>
            </div>
          </div>
          <div className="progress"><div className="bar" style={{ width: `${fin && job.status === 'done' ? 100 : pct}%` }} /><span>{Math.round(pct)}%</span></div>
          <div className="sp-list">{plan.units.map((u) => {
            const st = plan.chats.map((c) => ({ c, ...stateOf(u, c) }))
            const all = st.every((x) => x.s === 'ok'), any = st.some((x) => x.s === 'bad'), run = st.some((x) => x.s === 'run')
            const cls = any ? 'bad' : all ? 'ok' : run ? 'run' : 'wait'
            return (
              <div key={u.join('+')} className={`sp-row ${cls}`}>
                <i>{cls === 'ok' ? <CheckCircle2 size={18} /> : cls === 'bad' ? <AlertTriangle size={18} /> : cls === 'run' ? <Loader2 size={18} className="spin" /> : <Clock size={18} />}</i>
                <span><b>{unitTitle(u)}</b>
                  <small>{st.map((x) => <em key={x.c} className={`sp-chip ${x.s}`}>{x.s === 'ok' ? '✓' : x.s === 'bad' ? '✗' : x.s === 'run' ? '…' : '·'} {x.c}{x.e ? ` — ${x.e}` : ''}</em>)}</small></span>
              </div>)
          })}</div>
          {job?.status === 'error' && !nBad && <div className="alert"><AlertTriangle size={16} />Yuborishda kutilmagan xato bo'ldi. Qayta urinib ko'ring.</div>}
          <small className="hint">Yopib qo'ysangiz ham yuborish serverda davom etadi. Natijani «Xabar yuborish → Jurnal» dan ko'rishingiz mumkin.</small>
        </div>
      ) : (<>
        <div className="send-grid">
          <div>
            <div className="mp-sec dark">1. Qaysi fayllar</div>
            <div className="opts">{outs.map((o) => (
              <label key={o.k} className={`opt ${files.has(o.k) ? 'on' : ''}`}><input type="checkbox" checked={files.has(o.k)} onChange={() => flip(setFiles, o.k)} />
                <i>{o.ext === 'png' ? <ImageIcon size={20} /> : <FileSpreadsheet size={20} />}</i>
                <span><b>{o.title}</b><small>{o.ext === 'png' ? 'Rasm (jadval)' : `Excel fayl${o.rows != null ? ` · ${num(o.rows)} qator` : ''}${o.default ? '' : ' · qo\'shimcha'}`}</small></span></label>))}</div>
            <small className="hint">Ikkala rasm tanlansa — bitta albom (karusel) bo'lib ketadi, keyin Excel fayllar. Izohsiz yuboriladi.</small>
          </div>
          <div>
            <div className="mp-sec dark">2. Qaysi kanal yoki guruhga</div>
            {!chats ? <Spinner /> : chats.length === 0 ? (
              <div className="empty sm"><Megaphone size={30} /><div>Hali kanal yoki guruh qo'shilmagan. <Link to="/sozlamalar" onClick={onClose}>Sozlamalar</Link> bo'limidan qo'shing.</div></div>
            ) : <ChatTable chats={chats} sel={sel} busy={busy} onToggle={(id) => flip(setSel, id)} onAll={(v) => setSel(v ? new Set(chats.map((c) => c.id)) : new Set())} />}
          </div>
        </div>
        <label className={`ack-opt ${ack ? 'on' : ''}`}><input type="checkbox" checked={ack} onChange={(e) => setAck(e.target.checked)} />
          <i><MailCheck size={18} /></i><span><b>«Tanishdim» tugmasi</b><small>Oxirgi fayl tagida tugma chiqadi; kim bosgani «Xabar yuborish → Jurnal» da ko'rinadi</small></span></label>
      </>)}
    </Modal>
  )
}

/* ------------------------------------------------------------------ bitta kun: holat, jadvallar, amallar */
function Batch({ id, onChanged, onDeleted, defaults }) {
  const { can } = useAuth()
  const toast = useToast()
  const [b, setB] = useState(null)
  const [send, setSend] = useState(false)
  const [del, setDel] = useState(false)
  const [map, setMap] = useState({})
  const [busy, setBusy] = useState('')
  const live = b && (b.status === 'queued' || b.status === 'running')
  const load = useCallback(() => api.get(`/daily/${id}`).then((d) => { setB(d); onChanged?.(d) }).catch((e) => toast(e.message, 'err')), [id])
  useEffect(() => { setB(null); load() }, [id])
  useEffect(() => { if (!live) return undefined; const t = setInterval(load, 1200); return () => clearInterval(t) }, [live, load])
  useEffect(() => { if (b?.status === 'ask') setMap(Object.fromEntries(b.ask.map((a) => [a.value, '']))) }, [b?.status])
  if (!b) return <Spinner />
  const run = async (name, fn, ok) => { setBusy(name); try { await fn(); if (ok) toast(ok); await load() } catch (e) { toast(e.message, 'err') } finally { setBusy('') } }
  const dl = (which, fallback) => run(which, () => download(`/daily/${id}/file/${which}`, fallback))
  const zip = (what) => run('zip' + what, () => download(`/daily/${id}/zip/${what}`, `Kunlik_${what}.zip`))
  return (
    <div className="daily-batch">
      <div className="daily-head">
        <h3><ClipboardList size={20} />{dmy(b.date)} <small className="mut">· {b.by}, {dt(b.at)}</small></h3>
        <div className="row-btns">
          {b.status === 'done' && can('daily.send') && can('telegram.send') && <button className="btn primary" onClick={() => setSend(true)}><Send size={16} />Telegramga yuborish</button>}
          {(can('daily.recompute') || can('daily.upload')) && !live && <button className="btn ghost" disabled={!!busy} onClick={() => run('re', () => api.post(`/daily/${id}/recompute`), 'Qayta hisoblash boshlandi')} title="Sozlamalar o'zgargan bo'lsa"><RefreshCw size={16} />Qayta hisoblash</button>}
          {can('daily.delete') && <button className="btn ghost danger" onClick={() => setDel(true)}><Trash2 size={16} />O'chirish</button>}
        </div>
      </div>
      <div className="daily-files">{KINDS.map((x) => { const f = b.files[x.k]; return (
        <div key={x.k} className={`dfile ${f ? 'ok' : ''}`}><FileArchive size={16} /><span><b>{x.label}</b><small>{f ? `${f.name} · ${mb(f.size)}${f.rows != null ? ` · ${num(f.rows)} qator` : ''}` : '—'}</small></span>
          {f && can('daily.original') && <button className="icon-btn" title="Asl faylni yuklab olish" onClick={() => dl(x.k, f.name)}><Download size={15} /></button>}</div>) })}
        {can('daily.original') && <button className="btn ghost sm" disabled={!!busy} onClick={() => zip('orig')}><Package size={15} />Asl fayllar (ZIP)</button>}
      </div>
      {live && <div className="send-prog"><div className="progress"><div className="bar" style={{ width: `${Math.max(b.progress, 4)}%` }} /><span>{Math.round(b.progress)}%</span></div><div className="mut"><Loader2 size={14} className="spin" /> {b.message || 'Navbatda…'}</div></div>}
      {b.status === 'error' && <div className="alert"><AlertTriangle size={16} />{b.message}</div>}
      {b.status === 'ask' && (
        <div className="card pad ask-card">
          <h4><AlertTriangle size={17} />Iste'molchi turini belgilang</h4>
          <p className="mut">Fayldagi quyidagi turlar qaysi guruhga kirishini ko'rsating. Javob saqlanadi — keyingi yuklashlarda qayta so'ralmaydi.</p>
          {b.ask.map((a) => (
            <label key={a.value} className="ask-row"><span><b>{a.value}</b><small className="mut"> · {num(a.count)} ta hisoblagich</small></span>
              <select value={map[a.value] || ''} onChange={(e) => setMap({ ...map, [a.value]: e.target.value })}><option value="">— tanlang —</option>{CATS.map(([k, l]) => <option key={k} value={k}>{l}</option>)}</select></label>))}
          {(can('daily.recompute') || can('daily.upload'))
            ? <button className="btn primary" disabled={!!busy || b.ask.some((a) => !map[a.value])} onClick={() => run('types', () => api.post(`/daily/${id}/types`, { map }), 'Saqlandi, hisoblanmoqda')}><Save size={16} />Saqlash va davom etish</button>
            : <div className="mut">Buni «5 ta Excel faylni yuklash» ruxsati bor xodim belgilaydi.</div>}
        </div>)}
      {b.status === 'done' && (<>
        {can('daily.download') && <div className="row-btns daily-dl">
          {(b.outs || []).map((o) => <button key={o.k} className="btn ghost" disabled={!!busy} onClick={() => dl(o.k, `${o.title}.${o.ext}`)} title={o.default ? '' : 'Qo\'shimcha (Telegramga standart yuborilmaydi)'}>{o.ext === 'png' ? <ImageIcon size={16} /> : <FileSpreadsheet size={16} />}{o.title}{o.rows != null ? ` · ${num(o.rows)}` : ''}</button>)}
          <button className="btn ghost" disabled={!!busy} onClick={() => zip('out')}><Package size={16} />Hammasi (ZIP)</button>
        </div>}
        {b.tables.map((tb) => <DailyTable key={tb.key} tb={tb} region={b.region} date={b.date} />)}
      </>)}
      {send && <SendModal b={b} defaults={defaults} onClose={() => setSend(false)} />}
      {del && <Confirm icon={Trash2} title="Kunni o'chirish" ok="Ha, o'chirish" danger onOk={() => run('del', async () => { await api.del(`/daily/${id}`); setDel(false); onDeleted?.() }, "O'chirildi")} onCancel={() => setDel(false)}>
        {dmy(b.date)} sanasidagi yuklangan fayllar, jadvallar va tayyor Excel fayllar serverdan o'chiriladi. <small className="hint">Buni qaytarib bo'lmaydi.</small></Confirm>}
    </div>
  )
}

/* ------------------------------------------------------------------ Fayl yuklash tabi */
function UploadTab({ defaults }) {
  const toast = useToast()
  const { can } = useAuth()
  const [files, setFiles] = useState([])
  const [day, setDay] = useState('')
  const [pr, setPr] = useState(null)
  const [cur, setCur] = useState(null)
  const ref = useRef(null)
  const [over, setOver] = useState(false)
  const add = (list) => setFiles((old) => {
    const m = new Map(old.map((f) => [f.name, f]))
    ;[...list].forEach((f) => m.set(f.name, f))
    return [...m.values()]
  })
  const by = Object.fromEntries(files.map((f) => [kindOf(f.name), f]))
  const ok = files.length === 5 && KINDS.every((x) => by[x.k])
  const go = async () => {
    const form = new FormData()
    files.forEach((f) => form.append('files', f))
    form.append('day', day)
    setPr(0)
    try { const r = await uploadForm('/daily/upload', form, setPr); setCur(r.id); setFiles([]); toast(r.replaced ? 'Shu sana qayta yuklandi — jadvallar tayyorlanmoqda' : 'Fayllar yuklandi — jadvallar tayyorlanmoqda') }
    catch (e) { toast(e.message, 'err') } finally { setPr(null) }
  }
  if (!can('daily.upload')) return <div className="card pad"><Empty icon={UploadCloud}>Fayl yuklash uchun ruxsat berilmagan. Arxivdan tayyor fayllarni ko'rishingiz mumkin.</Empty></div>
  return (
    <div className="daily-upload">
      <div className="card pad">
        <h3 className="sec-h"><UploadCloud size={20} />Bugungi 5 ta yangi Excel fayl</h3>
        <div className={`drop ${over ? 'over' : ''} ${files.length ? 'has' : ''}`} onClick={() => ref.current.click()}
          onDragOver={(e) => { e.preventDefault(); setOver(true) }} onDragLeave={() => setOver(false)}
          onDrop={(e) => { e.preventDefault(); setOver(false); add(e.dataTransfer.files) }}>
          <input ref={ref} type="file" accept=".xlsx" multiple hidden onChange={(e) => { add(e.target.files); e.target.value = '' }} />
          <div className="drop-ic"><UploadCloud size={30} /></div>
          <b>5 ta faylni bir vaqtda tashlang yoki tanlang</b>
          <small>AreaInformationReport · CommissioningStatus · DirectMeter · NoMeterData · Online_Device_Monitoring (.xlsx)</small>
        </div>
        <div className="daily-files">{KINDS.map((x) => { const f = by[x.k]; return (
          <div key={x.k} className={`dfile ${f ? 'ok' : ''}`}>{f ? <CheckCircle2 size={16} /> : <FileArchive size={16} />}<span><b>{x.label}</b><small>{f ? `${f.name} · ${mb(f.size)}` : 'tanlanmagan'}</small></span>
            {f && <button className="icon-btn" onClick={() => setFiles(files.filter((y) => y !== f))} title="Olib tashlash"><X size={15} /></button>}</div>) })}</div>
        {files.some((f) => !kindOf(f.name)) && <small className="hint">Ba'zi fayl nomlari tanish emas — server fayl turini ustunlar tartibi va ma'lumot ko'rinishi bo'yicha o'zi aniqlaydi.</small>}
        <div className="daily-go">
          <label className="field"><span>Sana (bo'sh qoldirsangiz — bugungi kun)</span><input type="date" value={day} onChange={(e) => setDay(e.target.value)} /></label>
          <button className="btn primary" disabled={files.length !== 5 || pr !== null} onClick={go}>{pr !== null ? <Loader2 size={16} className="spin" /> : <UploadCloud size={16} />}Yuklash va jadvallarni tayyorlash{pr !== null ? ` · ${Math.round(pr * 100)}%` : ''}</button>
        </div>
        {files.length > 0 && !ok && files.length === 5 && <small className="hint">Bir xil turdagi ikkita fayl bor bo'lishi mumkin — server tekshiradi.</small>}
      </div>
      {cur && <Batch id={cur} defaults={defaults} onDeleted={() => setCur(null)} />}
    </div>
  )
}

/* ------------------------------------------------------------------ Arxiv tabi */
const ST = { queued: ['Navbatda', 'amber'], running: ['Hisoblanmoqda', 'blue'], ask: ['Javob kutilmoqda', 'amber'], done: ['Tayyor', 'green'], error: ['Xatolik', 'red'] }

function ArchiveTab({ defaults }) {
  const [list, setList] = useState(null)
  const [open, setOpen] = useState(null)
  const toast = useToast()
  const load = () => api.get('/daily').then(setList).catch((e) => { toast(e.message, 'err'); setList([]) })
  useEffect(() => { load() }, [])
  if (!list) return <Spinner />
  return (
    <div>
      {list.length === 0 ? <div className="card pad"><Empty icon={Archive}>Arxiv bo'sh. «Fayl yuklash» tabidan birinchi kunni yuklang.</Empty></div> : (
        <div className="card tcard"><div className="tbl-scroll"><table className="list">
          <thead><tr><th>Sana</th><th>Holat</th><th>Qatorlar (aloqasiz / offline / primichka)</th><th>Yuklagan</th><th /></tr></thead>
          <tbody>{list.map((x) => { const s = ST[x.status] || ST.error; return (
            <tr key={x.id}><td className="b nowrap-d">{dmy(x.date)}</td>
              <td><span className={`tag ${s[1]}`}>{s[0]}</span>{x.status === 'error' && <div className="job-err mut">{x.message}</div>}</td>
              <td className="mut">{x.ready ? `${num(x.counts.nometer)} / ${num(x.counts.offline)} / ${num(x.counts.direct)}` : '—'}</td>
              <td className="mut">{x.by}<div>{dt(x.at)}</div></td>
              <td className="acts"><button className="btn ghost sm" onClick={() => setOpen(x.id)}><Eye size={15} />Ochish</button></td></tr>) })}</tbody></table></div></div>)}
      {open && <Modal wide icon={Archive} title="Kunlik topshiriq" onClose={() => { setOpen(null); load() }}>
        <Batch id={open} defaults={defaults} onChanged={() => {}} onDeleted={() => { setOpen(null); load() }} /></Modal>}
    </div>
  )
}

/* ------------------------------------------------------------------ Sozlamalar tabi */
function SettingsTab({ onSaved }) {
  const toast = useToast()
  const [s, setS] = useState(null)
  const [f, setF] = useState(null)
  const [chats, setChats] = useState([])
  const [busy, setBusy] = useState(false)
  const load = () => api.get('/daily/settings').then((r) => { setS(r); setF({ ...r, time_edges_txt: r.time_edges.join(', '), esp_txt: r.esp_order.join('\n') }) }).catch((e) => toast(e.message, 'err'))
  useEffect(() => { load(); api.get('/daily/chats').then(setChats).catch(() => {}) }, [])
  if (!f) return <Spinner />
  const set = (k, v) => setF({ ...f, [k]: v })
  const move = (i, d) => { const a = f.esp_txt.split('\n').filter(Boolean); const j = i + d; if (j < 0 || j >= a.length) return; [a[i], a[j]] = [a[j], a[i]]; set('esp_txt', a.join('\n')) }
  const esps = f.esp_txt.split('\n').map((x) => x.trim()).filter(Boolean)
  const edges = f.time_edges_txt.split(/[,\s]+/).filter(Boolean).map(Number)
  const save = async () => {
    setBusy(true)
    try {
      const body = { region: f.region, t1_title: f.t1_title, t2_title: f.t2_title, task_title: f.task_title, offline_days: Number(f.offline_days), time_edges: edges,
        esp_order: esps, types: f.types, fn_t1: f.fn_t1, fn_t2: f.fn_t2, fn_task: f.fn_task, chats: f.chats, titles: f.titles || {} }
      const r = await api.put('/daily/settings', body)
      toast('Saqlandi. Mavjud kunlar uchun «Qayta hisoblash» ni bosing'); onSaved?.(r); await load()
    } catch (e) { toast(e.message, 'err') } finally { setBusy(false) }
  }
  const chatSet = (k, id) => { const cur = new Set(f.chats[k] || []); cur.has(id) ? cur.delete(id) : cur.add(id); set('chats', { ...f.chats, [k]: [...cur] }) }
  const types = Object.entries(f.types || {})
  return (
    <div className="daily-set">
      <section className="card pad set-card">
        <h3><ClipboardList size={20} />Jadvallar va fayl nomlari</h3>
        <label className="field"><span>Hudud nomi (jadval tepasida)</span><input value={f.region} onChange={(e) => set('region', e.target.value)} /></label>
        {[['t1', 'Birinchi jadval'], ['t2', 'Ikkinchi jadval'], ['task', 'Nomma-nom topshiriq fayli']].map(([k, lbl]) => (
          <div key={k} className="two set-pair">
            <label className="field"><span>{lbl} — nomi</span><input value={f[`${k}_title`]} onChange={(e) => set(`${k}_title`, e.target.value)} /></label>
            <label className="field"><span>Fayl nomi shabloni</span><input value={f[`fn_${k}`]} onChange={(e) => set(`fn_${k}`, e.target.value)} />
              <small className="hint">Namuna: <b>{s.examples[k]}</b></small></label>
          </div>))}
        <h4 className="set-sub">Yuboriladigan 7 ta nomma-nom fayl nomlari</h4>
        {s.list_titles.map((x) => (
          <label key={x.k} className="field"><span>{x.default}</span>
            <input value={(f.titles || {})[x.k] ?? ''} placeholder={x.default} onChange={(e) => set('titles', { ...(f.titles || {}), [x.k]: e.target.value })} />
            <small className="hint">Namuna: <b>{s.examples[x.k]}</b></small></label>))}
        <small className="hint">Bo'sh qoldirsangiz — standart nom ishlatiladi. Fayl nomi yuqoridagi «Nomma-nom topshiriq fayli» shabloni bo'yicha tuziladi ({'{nom}'} o'rniga shu nom qo'yiladi). Ikkala jadval rasmi nomi — birinchi va ikkinchi jadval nomidan olinadi.</small>
        <small className="hint">Shablon o'rin belgilari: {Object.entries(s.placeholders).map(([k, v]) => <span key={k} className="fn-ph"><code>{`{${k}}`}</code> {v}</span>)}. Fayl nomidagi o'zgarish keyingi yuklab olish/yuborishdan kuchga kiradi.</small>
      </section>
      <section className="card pad set-card">
        <h3><RefreshCw size={20} />Hisoblash qoidalari</h3>
        <div className="two">
          <label className="field"><span>Offline: oxirgi necha kun chiqarib tashlanadi</span><input type="number" min="1" max="60" value={f.offline_days} onChange={(e) => set('offline_days', e.target.value)} />
            <small className="hint">3 bo'lsa — bugun, kecha va undan oldingi kun (21, 22, 23.11) offlinelari «shundan {f.offline_days} kundan ortiq» ga kirmaydi.</small></label>
          <label className="field"><span>Aloqasiz hisoblagich: kun oraliqlari</span><input value={f.time_edges_txt} onChange={(e) => set('time_edges_txt', e.target.value)} placeholder="2, 7, 30, 90" />
            <small className="hint">Ustunlar: {edges.length >= 2 && edges.every((x, i) => Number.isInteger(x) && (i === 0 || x > edges[i - 1])) ? labelsOf(edges).join(' · ') : 'o\'sib boruvchi butun sonlar kiriting'}</small></label>
        </div>
        <small className="hint">Obxod oraliqlari: 0% → «0%»; 0 dan 50 gacha (50 kiradi); 50–80; 80–100. Iste'molchi biriktirilmagan — hisoblagichi yo'q kontsentrator.</small>
      </section>
      <section className="card pad set-card">
        <h3><Settings2 size={20} />Rayonlar tartibi</h3>
        <div className="esp-list">{esps.map((e, i) => (
          <div key={e} className="esp-row"><span className="mut">{i + 1}.</span><b>{e}</b>
            <button className="icon-btn" onClick={() => move(i, -1)} disabled={i === 0} title="Yuqoriga"><ArrowUp size={15} /></button>
            <button className="icon-btn" onClick={() => move(i, 1)} disabled={i === esps.length - 1} title="Pastga"><ArrowDown size={15} /></button>
            <button className="icon-btn danger" onClick={() => set('esp_txt', esps.filter((x) => x !== e).join('\n'))} title="Ro'yxatdan olib tashlash"><X size={15} /></button></div>))}</div>
        <label className="field"><span>Qo'lda tahrirlash (har qatorda bitta rayon)</span><textarea rows={4} value={f.esp_txt} onChange={(e) => set('esp_txt', e.target.value)} /></label>
        <small className="hint">Fayllarda uchragan, lekin bu ro'yxatda yo'q rayonlar avtomatik oxiriga qo'shiladi. Nomlar fayldagidek yoziladi (ShETK / TETK).</small>
      </section>
      <section className="card pad set-card">
        <h3><Megaphone size={20} />Standart kanal va guruhlar</h3>
        <small className="hint">Telegramga yuborishda shu kanallar oldindan belgilanadi (yuborishda o'zgartirish mumkin). Bot va kanallar — umumiy: Sozlamalar → Telegram.</small>
        {chats.length === 0 ? <div className="mut" style={{ marginTop: 10 }}>Hali kanal yoki guruh qo'shilmagan.</div> : (
          <div className="chat-pick">{GROUPS.map((o) => (
            <div key={o.k}><b>{o.note}</b>{chats.map((c) => <label key={c.id} className="chk"><input type="checkbox" checked={(f.chats[o.k] || []).includes(c.id)} onChange={() => chatSet(o.k, c.id)} />{c.title}</label>)}</div>))}</div>)}
      </section>
      <section className="card pad set-card">
        <h3><Archive size={20} />Iste'molchi turlari (saqlangan javoblar)</h3>
        {types.length === 0 ? <div className="mut">Hozircha saqlangan javob yo'q. Fayldagi tur tushunarsiz bo'lsa, yuklashda bir marta so'raladi.</div> : types.map(([k, v]) => (
          <div key={k} className="ask-row"><b>{k}</b>
            <select value={v} onChange={(e) => set('types', { ...f.types, [k]: e.target.value })}>{CATS.map(([c, l]) => <option key={c} value={c}>{l}</option>)}</select>
            <button className="icon-btn danger" onClick={() => { const n = { ...f.types }; delete n[k]; set('types', n) }} title="Olib tashlash"><Trash2 size={15} /></button></div>))}
        <small className="hint">Бытовые → Aholi, Промышленные → Ulgurji, Индикатор баланса → Balans avtomatik taniladi.</small>
      </section>
      <div className="row-btns"><button className="btn primary" disabled={busy} onClick={save}><Save size={16} />Saqlash</button></div>
    </div>
  )
}

const labelsOf = (e) => [...e.slice(0, -1).map((a, i) => { const b = e[i + 1]; return b > 30 && a % 30 === 0 && b % 30 === 0 ? `${a / 30}-${b / 30} oy` : `${a}-${b} kun` }),
  e[e.length - 1] >= 30 && e[e.length - 1] % 30 === 0 ? `${e[e.length - 1] / 30} oydan ortiq` : `${e[e.length - 1]} kundan ortiq`]

/* ------------------------------------------------------------------ sahifa */
export default function Daily() {
  const { can } = useAuth()
  const [sp, setSp] = useSearchParams()
  const [cfg, setCfg] = useState(null)
  useEffect(() => { api.get('/daily/settings').then(setCfg).catch(() => setCfg({})) }, [])
  const tabs = [{ k: 'yuklash', label: 'Fayl yuklash', icon: UploadCloud }, { k: 'arxiv', label: 'Arxiv', icon: Archive },
    ...(can('daily.settings') ? [{ k: 'sozlamalar', label: 'Sozlamalar', icon: Settings2 }] : [])]
  const tab = (tabs.find((t) => t.k === sp.get('t')) || tabs[0]).k
  const defaults = cfg?.chats || {}
  if (!cfg) return <Spinner />
  return (
    <div className="daily">
      <div className="tabs" role="tablist">{tabs.map((t) => (
        <button key={t.k} role="tab" aria-selected={t.k === tab} className={`tab ${t.k === tab ? 'on' : ''}`} onClick={() => setSp(t.k === 'yuklash' ? {} : { t: t.k }, { replace: true })}><t.icon size={18} /><span>{t.label}</span></button>))}</div>
      {tab === 'yuklash' && <UploadTab defaults={defaults} />}
      {tab === 'arxiv' && <ArchiveTab defaults={defaults} />}
      {tab === 'sozlamalar' && <SettingsTab onSaved={setCfg} />}
    </div>
  )
}
