"""Ruxsatlar katalogi. Sadmin barcha ruxsatlarga ega; qolganlariga sadmin belgilaydi."""

PERMS = [
    # (kod, guruh, nomi)
    ("view.konsentrator", "Sahifalar", "Konsentratorlar dinamikasi jadvali"),
    ("view.aloqa", "Sahifalar", "Aloqadan chiqqan hisoblagichlar jadvali"),
    ("view.obxod", "Sahifalar", "48 soat obxod jadvali"),
    ("brigade.view", "Sahifalar", "Brigadalar sahifasi"),
    ("drill.view", "Amallar", "Raqam ustiga bosib nomma-nom ro'yxatni ko'rish"),
    ("export", "Amallar", "Ro'yxatni Excel'ga yuklab olish"),
    ("dynamics.compare", "Amallar", "Dinamika sanalarini o'zgartirib solishtirish"),
    ("brigade.edit", "Amallar", "Brigada nomi va xodimlarini tahrirlash"),
    ("brigade.assign", "Amallar", "TP'larni brigadaga biriktirish / ko'chirish"),
    ("data.upload", "Amallar", "Ma'lumot fayllarini yuklash"),
]
PERM_CODES = {p[0] for p in PERMS}
