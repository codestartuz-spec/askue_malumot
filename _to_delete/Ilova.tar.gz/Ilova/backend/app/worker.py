"""Alohida jarayon: yuklash navbatidagi ishlarni ketma-ket bajaradi.
Ishga tushirish:  python -m app.worker"""
import time
from datetime import datetime

from sqlalchemy import text

from .db import engine
from .init_db import init_db
from .services.jobs import run_job, start_heartbeat


def claim() -> int | None:
    with engine.begin() as c:
        row = c.execute(text("SELECT id FROM jobs WHERE status='queued' ORDER BY id LIMIT 1")).first()
        return row[0] if row else None


def main() -> None:
    init_db()
    with engine.begin() as c:   # oldingi ish o'rtasida to'xtab qolgan bo'lsa
        c.execute(text("UPDATE jobs SET status='error', stage='Xatolik', "
                       "message='Jarayon to''xtatilgan (worker qayta ishga tushdi)', finished_at=:t "
                       "WHERE status='running'"), {"t": datetime.now()})
    start_heartbeat()
    print("Worker ishga tushdi. Navbat kutilmoqda...", flush=True)
    while True:
        job_id = claim()
        if job_id:
            print(f"Ish #{job_id} boshlandi", flush=True)
            run_job(job_id)
            print(f"Ish #{job_id} tugadi", flush=True)
        else:
            time.sleep(2)


if __name__ == "__main__":
    main()
