from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import log, sadmin_only
from ..models import User
from ..perms import PERM_CODES
from ..security import hash_password
from .auth import user_out

router = APIRouter(prefix="/users", tags=["users"])


class UserIn(BaseModel):
    username: str
    full_name: str = ""
    password: str
    perms: list[str] = []


class UserPatch(BaseModel):
    full_name: str | None = None
    perms: list[str] | None = None
    is_active: bool | None = None
    password: str | None = None


def _clean(perms: list[str]) -> list[str]:
    return sorted(p for p in set(perms) if p in PERM_CODES)


@router.get("")
def list_users(_: User = Depends(sadmin_only), db: Session = Depends(get_db)):
    return [user_out(u) for u in db.scalars(select(User).order_by(User.is_super.desc(), User.id))]


@router.post("")
def create_user(body: UserIn, me: User = Depends(sadmin_only), db: Session = Depends(get_db)):
    name = body.username.strip().lower()
    if len(name) < 3 or not name.replace("_", "").replace(".", "").isalnum():
        raise HTTPException(400, "Login kamida 3 ta harf/raqamdan iborat bo'lsin")
    if len(body.password) < 6:
        raise HTTPException(400, "Parol kamida 6 belgidan iborat bo'lsin")
    if db.scalar(select(User).where(User.username == name)):
        raise HTTPException(400, "Bunday login mavjud")
    u = User(username=name, full_name=body.full_name.strip(), password_hash=hash_password(body.password),
             perms=_clean(body.perms))
    db.add(u)
    log(db, me.username, "xodim_qo'shildi", f"{name}: {u.perms}")
    db.commit()
    return user_out(u)


@router.patch("/{uid}")
def patch_user(uid: int, body: UserPatch, me: User = Depends(sadmin_only), db: Session = Depends(get_db)):
    u = db.get(User, uid)
    if not u:
        raise HTTPException(404, "Topilmadi")
    if u.is_super and (body.perms is not None or body.is_active is False):
        raise HTTPException(400, "Sadmin ruxsatlarini o'zgartirib bo'lmaydi")
    changes = []
    if body.full_name is not None:
        u.full_name = body.full_name.strip()
    if body.perms is not None:
        old = set(u.perms or [])
        u.perms = _clean(body.perms)
        changes.append(f"ruxsatlar: +{sorted(set(u.perms) - old)} -{sorted(old - set(u.perms))}")
    if body.is_active is not None and body.is_active != u.is_active:
        u.is_active = body.is_active
        changes.append("faol" if u.is_active else "bloklandi")
    if body.password:
        if len(body.password) < 6:
            raise HTTPException(400, "Parol kamida 6 belgidan iborat bo'lsin")
        u.password_hash = hash_password(body.password)
        changes.append("parol almashtirildi")
    log(db, me.username, "xodim_o'zgardi", f"{u.username}: {'; '.join(changes) or 'ism'}")
    db.commit()
    return user_out(u)
