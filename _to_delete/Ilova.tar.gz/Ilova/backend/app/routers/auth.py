from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Request
from pydantic import BaseModel
from sqlalchemy import select
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import current_user, log
from ..models import User
from ..perms import PERM_CODES
from ..security import (clear_fails, hash_password, make_token, register_fail, too_many_attempts,
                        verify_password)

router = APIRouter(prefix="/auth", tags=["auth"])


def user_out(u: User) -> dict:
    return {"id": u.id, "username": u.username, "full_name": u.full_name, "is_super": u.is_super,
            "is_active": u.is_active, "perms": sorted(PERM_CODES) if u.is_super else (u.perms or []),
            "last_login": u.last_login.isoformat() if u.last_login else None}


class LoginIn(BaseModel):
    username: str
    password: str


@router.post("/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)):
    key = f"{request.client.host if request.client else '?'}|{body.username.lower()}"
    if too_many_attempts(key):
        raise HTTPException(429, "Urinishlar ko'p. Bir necha daqiqadan keyin qayta urinib ko'ring")
    u = db.scalar(select(User).where(User.username == body.username.strip()))
    if not u or not u.is_active or not verify_password(body.password, u.password_hash):
        register_fail(key)
        raise HTTPException(401, "Login yoki parol noto'g'ri")
    clear_fails(key)
    u.last_login = datetime.now()
    db.commit()
    return {"token": make_token(u.id), "user": user_out(u)}


@router.get("/me")
def me(user: User = Depends(current_user)):
    return user_out(user)


class PwIn(BaseModel):
    old_password: str
    new_password: str


@router.post("/change-password")
def change_password(body: PwIn, user: User = Depends(current_user), db: Session = Depends(get_db)):
    if not verify_password(body.old_password, user.password_hash):
        raise HTTPException(400, "Joriy parol noto'g'ri")
    if len(body.new_password) < 6:
        raise HTTPException(400, "Yangi parol kamida 6 belgidan iborat bo'lsin")
    user.password_hash = hash_password(body.new_password)
    log(db, user.username, "parol", "Parol almashtirildi")
    db.commit()
    return {"ok": True}
