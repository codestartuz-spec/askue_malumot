import time

from fastapi import APIRouter, Depends
from sqlalchemy import text
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import current_user
from ..models import User
from ..perms import PERMS
from .auth import user_out

router = APIRouter(prefix="/meta", tags=["meta"])


@router.get("/bootstrap")
def bootstrap(user: User = Depends(current_user), db: Session = Depends(get_db)):
    esps = [dict(r) for r in db.execute(text(
        "SELECT id, name, label FROM esps ORDER BY sort, label")).mappings()]
    dates = [r[0].isoformat() for r in db.execute(text(
        "SELECT DISTINCT snap_date FROM snapshots ORDER BY snap_date DESC"))]
    last = db.execute(text(
        "SELECT id, snap_date, finished_at, created_by FROM jobs WHERE status='done' "
        "ORDER BY id DESC LIMIT 1")).mappings().first()
    hb = db.execute(text("SELECT v FROM kv WHERE k='worker_heartbeat'")).scalar()
    return {
        "user": user_out(user), "esps": esps, "dates": dates,
        "last_upload": {"id": last["id"], "snap_date": last["snap_date"].isoformat(),
                        "finished_at": last["finished_at"].isoformat() if last["finished_at"] else None,
                        "by": last["created_by"]} if last else None,
        "worker_alive": bool(hb and time.time() - int(hb) < 20),
        "perms": [{"code": c, "group": g, "name": n} for c, g, n in PERMS],
    }
