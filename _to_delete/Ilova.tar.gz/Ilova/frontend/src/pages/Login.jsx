import { useState } from 'react'
import { LogIn, User, Lock, Eye, EyeOff, Zap } from 'lucide-react'
import { useAuth } from '../auth'
import { Logo } from '../ui'
import EnergyBackground from '../bg'

export default function Login() {
  const { login } = useAuth()
  const [u, setU] = useState('')
  const [p, setP] = useState('')
  const [show, setShow] = useState(false)
  const [err, setErr] = useState('')
  const [busy, setBusy] = useState(false)
  const submit = async (e) => {
    e.preventDefault(); setErr(''); setBusy(true)
    try { await login(u.trim(), p) } catch (x) { setErr(x.message) } finally { setBusy(false) }
  }
  return (
    <div className="login-wrap">
      <EnergyBackground intensity={1.25} />
      <form className="login-card" onSubmit={submit}>
        <div className="login-logo"><Logo theme="dark" height={78} /></div>
        <div className="login-title"><Zap size={18} /><span>ASKUE ma'lumot</span></div>
        <p className="login-sub">Qashqadaryo hududiy elektr tarmoqlari — hisoblash tizimi monitoringi</p>
        <label className="input-ic"><User size={18} /><input autoFocus placeholder="Login" value={u} onChange={(e) => setU(e.target.value)} autoComplete="username" /></label>
        <label className="input-ic"><Lock size={18} />
          <input placeholder="Parol" type={show ? 'text' : 'password'} value={p} onChange={(e) => setP(e.target.value)} autoComplete="current-password" />
          <button type="button" className="eye" onClick={() => setShow(!show)} tabIndex={-1}>{show ? <EyeOff size={18} /> : <Eye size={18} />}</button>
        </label>
        {err && <div className="login-err">{err}</div>}
        <button className="btn primary big" disabled={busy || !u || !p}><LogIn size={18} />{busy ? 'Kirilmoqda…' : 'Kirish'}</button>
      </form>
    </div>
  )
}
