import { useEffect, useState } from 'react'
import { UserPlus, Pencil, ShieldCheck, Ban, CheckCircle2, KeyRound, Users as UsersIcon, Crown } from 'lucide-react'
import { api } from '../api'
import { useAuth } from '../auth'
import { Modal, Spinner, useToast } from '../ui'
import { dt } from '../fmt'

function PermGrid({ catalog, value, onChange }) {
  const groups = [...new Set(catalog.map((p) => p.group))]
  const toggle = (c) => onChange(value.includes(c) ? value.filter((x) => x !== c) : [...value, c])
  return groups.map((g) => (
    <div key={g} className="perm-group">
      <div className="pg-title">{g}</div>
      {catalog.filter((p) => p.group === g).map((p) => (
        <label key={p.code} className="check"><input type="checkbox" checked={value.includes(p.code)} onChange={() => toggle(p.code)} /><span>{p.name}</span></label>))}
    </div>))
}

function UserModal({ u, catalog, onClose, onSaved }) {
  const toast = useToast()
  const isNew = !u
  const [f, setF] = useState({ username: '', full_name: u?.full_name || '', password: '', perms: u?.perms || ['view.konsentrator', 'view.aloqa', 'view.obxod'] })
  const [busy, setBusy] = useState(false)
  const save = async () => {
    setBusy(true)
    try {
      if (isNew) await api.post('/users', f)
      else await api.patch(`/users/${u.id}`, { full_name: f.full_name, perms: f.perms, ...(f.password ? { password: f.password } : {}) })
      toast('Saqlandi'); onSaved(); onClose()
    } catch (e) { toast(e.message, 'err') } finally { setBusy(false) }
  }
  return (
    <Modal wide icon={isNew ? UserPlus : Pencil} title={isNew ? "Yangi xodim qo'shish" : `Xodim: ${u.username}`} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>Bekor qilish</button><button className="btn primary" disabled={busy || (isNew && (!f.username || !f.password))} onClick={save}>Saqlash</button></>}>
      <div className="two">
        {isNew && <label className="field"><span>Login</span><input value={f.username} onChange={(e) => setF({ ...f, username: e.target.value })} autoComplete="off" /></label>}
        <label className="field"><span>F.I.Sh.</span><input value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></label>
        <label className="field"><span><KeyRound size={14} />{isNew ? 'Parol' : 'Yangi parol (ixtiyoriy)'}</span><input type="text" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} autoComplete="new-password" /></label>
      </div>
      <div className="perm-title"><ShieldCheck size={17} />Ruxsatlar — xodim nimani ko'ra oladi va nima qila oladi</div>
      <div className="perm-grid"><PermGrid catalog={catalog} value={f.perms} onChange={(perms) => setF({ ...f, perms })} /></div>
      <small className="hint">Eslatma: «Ro'yxatni ko'rish» ruxsatisiz raqam ustiga bosganda nomma-nom ro'yxat ochilmaydi. Brigadalarni boshqarish uchun «Brigadalar sahifasi» ruxsati ham kerak.</small>
    </Modal>
  )
}

export default function Users() {
  const { boot } = useAuth()
  const toast = useToast()
  const [list, setList] = useState(null)
  const [edit, setEdit] = useState(undefined)   // undefined = yopiq, null = yangi
  const load = () => api.get('/users').then(setList).catch((e) => toast(e.message, 'err'))
  useEffect(() => { load() }, [])
  const toggle = async (u) => { try { await api.patch(`/users/${u.id}`, { is_active: !u.is_active }); load() } catch (e) { toast(e.message, 'err') } }
  const label = (c) => boot.perms.find((p) => p.code === c)?.name || c
  return (
    <div className="usr">
      <div className="card head-card">
        <div className="titles"><h2 className="ttl">Xodimlar va ruxsatlar</h2><p className="sub">Sadmin har bir xodim qaysi sahifalarni ko'rishi va qaysi amallarni bajarishini belgilaydi.</p></div>
        <div className="filters"><div className="spacer" /><button className="btn primary" onClick={() => setEdit(null)}><UserPlus size={17} />Xodim qo'shish</button></div>
      </div>
      {!list ? <Spinner /> : (
        <div className="card tcard"><div className="tbl-scroll">
          <table className="list users">
            <thead><tr><th>Login</th><th>F.I.Sh.</th><th>Ruxsatlar</th><th>Oxirgi kirish</th><th>Holati</th><th></th></tr></thead>
            <tbody>{list.map((u) => (
              <tr key={u.id} className={u.is_active ? '' : 'off'}>
                <td className="b">{u.is_super && <Crown size={15} className="crown" />} {u.username}</td><td>{u.full_name}</td>
                <td>{u.is_super ? <span className="tag blue">Barcha ruxsatlar</span> : u.perms.length ? <div className="tags">{u.perms.map((p) => <span key={p} className="tag">{label(p)}</span>)}</div> : <em className="mut">Ruxsat berilmagan</em>}</td>
                <td className="mut">{dt(u.last_login)}</td>
                <td>{u.is_active ? <span className="tag green"><CheckCircle2 size={13} />Faol</span> : <span className="tag red"><Ban size={13} />Bloklangan</span>}</td>
                <td className="acts">{!u.is_super && (<>
                  <button className="btn ghost sm" onClick={() => setEdit(u)}><Pencil size={15} />Tahrirlash</button>
                  <button className="btn ghost sm" onClick={() => toggle(u)}>{u.is_active ? 'Bloklash' : 'Faollashtirish'}</button></>)}</td>
              </tr>))}</tbody>
          </table></div></div>)}
      {edit !== undefined && <UserModal u={edit} catalog={boot.perms} onClose={() => setEdit(undefined)} onSaved={load} />}
    </div>
  )
}
