import { lazy, Suspense } from 'react'
import { Navigate, Route, Routes } from 'react-router-dom'
import { useAuth } from './auth'
import Layout from './Layout'
import Login from './pages/Login'
import EnergyBackground from './bg'
import { Spinner } from './ui'

const DynPage = lazy(() => import('./pages/DynPage'))
const Brigades = lazy(() => import('./pages/Brigades'))
const Upload = lazy(() => import('./pages/Upload'))
const Users = lazy(() => import('./pages/Users'))
const Audit = lazy(() => import('./pages/Audit'))

function Guard({ perm, sadmin, children }) {
  const { can, user } = useAuth()
  if (sadmin ? !user?.is_super : perm && !can(perm)) return <div className="card pad denied">Bu sahifaga kirish uchun ruxsat berilmagan.</div>
  return children
}

export default function App() {
  const { user, loading } = useAuth()
  if (loading) return (<><EnergyBackground /><div className="boot"><Spinner label="Tizim yuklanmoqda…" /></div></>)
  if (!user) return <Login />
  return (
    <Layout>
      <Suspense fallback={<Spinner />}>
        <Routes>
          <Route path="/" element={<div className="home-blank" />} />
          <Route path="/konsentratorlar" element={<Guard perm="view.konsentrator"><DynPage key="k" table="konsentrator" /></Guard>} />
          <Route path="/aloqa" element={<Guard perm="view.aloqa"><DynPage key="a" table="aloqa" /></Guard>} />
          <Route path="/obxod" element={<Guard perm="view.obxod"><DynPage key="o" table="obxod" /></Guard>} />
          <Route path="/brigadalar" element={<Guard perm="brigade.view"><Brigades /></Guard>} />
          <Route path="/yuklash" element={<Guard perm="data.upload"><Upload /></Guard>} />
          <Route path="/xodimlar" element={<Guard sadmin><Users /></Guard>} />
          <Route path="/jurnal" element={<Guard sadmin><Audit /></Guard>} />
          <Route path="*" element={<Navigate to="/" replace />} />
        </Routes>
      </Suspense>
    </Layout>
  )
}
