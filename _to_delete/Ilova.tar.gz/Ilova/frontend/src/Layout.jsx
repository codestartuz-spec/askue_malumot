import { useEffect, useState } from 'react'
import { NavLink, useLocation } from 'react-router-dom'
import { Home, Radio, WifiOff, Gauge, HardHat, UploadCloud, Users, ScrollText, LogOut, KeyRound, Menu, Database, X, ChevronDown, Zap } from 'lucide-react'
import { useAuth } from './auth'
import { Logo, Modal, useToast } from './ui'
import EnergyBackground from './bg'
import { api } from './api'
import { dmy, dt } from './fmt'

const NAV = [
  { to: '/', icon: Home, label: 'Bosh sahifa', end: true },
  { group: 'Dinamika jadvallari' },
  { to: '/konsentratorlar', icon: Radio, label: 'Konsentratorlar', perm: 'view.konsentrator' },
  { to: '/aloqa', icon: WifiOff, label: 'Aloqadan chiqqanlar', perm: 'view.aloqa' },
  { to: '/obxod', icon: Gauge, label: '48 soat obxod', perm: 'view.obxod' },
  { group: 'Boshqaruv' },
  { to: '/brigadalar', icon: HardHat, label: 'Brigadalar', perm: 'brigade.view' },
  { to: '/yuklash', icon: UploadCloud, label: "Ma'lumot yuklash", perm: 'data.upload' },
  { to: '/xodimlar', icon: Users, label: 'Xodimlar va ruxsatlar', sadmin: true },
  { to: '/jurnal', icon: ScrollText, label: 'Harakatlar jurnali', sadmin: true },
]

function PasswordModal({ onClose }) {
  const toast = useToast()
  const [f, setF] = useState({ old_password: '', new_password: '' })
  const [busy, setBusy] = useState(false)
  const save = async () => {
    setBusy(true)
    try { await api.post('/auth/change-password', f); toast("Parol almashtirildi"); onClose() }
    catch (e) { toast(e.message, 'err') } finally { setBusy(false) }
  }
  return (
    <Modal title="Parolni almashtirish" icon={KeyRound} onClose={onClose}
      footer={<><button className="btn ghost" onClick={onClose}>Bekor qilish</button><button className="btn primary" disabled={busy} onClick={save}>Saqlash</button></>}>
      <label className="field"><span>Joriy parol</span><input type="password" value={f.old_password} onChange={(e) => setF({ ...f, old_password: e.target.value })} /></label>
      <label className="field"><span>Yangi parol</span><input type="password" value={f.new_password} onChange={(e) => setF({ ...f, new_password: e.target.value })} /></label>
    </Modal>
  )
}

export default function Layout({ children }) {
  const { user, can, boot, logout } = useAuth()
  const [open, setOpen] = useState(false)
  const [menu, setMenu] = useState(false)
  const [pw, setPw] = useState(false)
  const loc = useLocation()
  useEffect(() => { setOpen(false); setMenu(false) }, [loc.pathname])
  const items = NAV.filter((n) => n.group || (n.sadmin ? user.is_super : !n.perm || can(n.perm)))
  const shown = items.filter((n, i) => !n.group || (items[i + 1] && !items[i + 1].group))
  const title = NAV.find((n) => n.to && (n.end ? loc.pathname === n.to : loc.pathname.startsWith(n.to)))?.label || ''
  const lu = boot?.last_upload
  return (
    <div className="shell">
      <EnergyBackground />
      <aside className={`side ${open ? 'open' : ''}`}>
        <div className="side-logo">
          <Logo theme="dark" height={64} />
          <button className="icon-btn only-mobile" onClick={() => setOpen(false)}><X size={20} /></button>
        </div>
        <div className="side-brand"><Zap size={14} /><span>ASKUE ma'lumot</span></div>
        <nav>
          {shown.map((n, i) => n.group
            ? <div key={i} className="nav-group">{n.group}</div>
            : <NavLink key={n.to} to={n.to} end={n.end} className="nav-item"><n.icon size={19} /><span>{n.label}</span></NavLink>)}
        </nav>
        <div className="side-foot">
          <div className="foot-line"><span className="pulse-dot" />Qashqadaryo HETK</div>
        </div>
      </aside>
      {open && <div className="scrim" onClick={() => setOpen(false)} />}
      <div className="main">
        <header className="top">
          <button className="icon-btn only-mobile" onClick={() => setOpen(true)} aria-label="Menyu"><Menu size={22} /></button>
          <h1 className="top-title">{title}</h1>
          <div className="top-right">
            {lu && <div className="chip" title={`Yuklagan: ${lu.by}, ${dt(lu.finished_at)}`}><Database size={15} /><span>Ma'lumot: {dmy(lu.snap_date)}</span></div>}
            <div className="user" onClick={() => setMenu(!menu)}>
              <div className="avatar">{(user.full_name || user.username).slice(0, 1).toUpperCase()}</div>
              <div className="user-name"><b>{user.full_name || user.username}</b><small>{user.is_super ? 'Sadmin' : 'Xodim'}</small></div>
              <ChevronDown size={16} />
              {menu && (
                <div className="user-menu" onClick={(e) => e.stopPropagation()}>
                  <button onClick={() => { setPw(true); setMenu(false) }}><KeyRound size={16} />Parolni almashtirish</button>
                  <button onClick={logout}><LogOut size={16} />Chiqish</button>
                </div>
              )}
            </div>
          </div>
        </header>
        <main className="content">{children}</main>
      </div>
      {pw && <PasswordModal onClose={() => setPw(false)} />}
    </div>
  )
}
