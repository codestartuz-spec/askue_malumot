"""Ruxsatlar katalogi. Sadmin barcha ruxsatlarga ega; qolganlariga sadmin belgilaydi."""

PERMS = [
    # (kod, guruh, nomi)
    ("view.konsentrator", "Sahifalar", "Konsentratorlar dinamikasi jadvali"),
    ("view.aloqa", "Sahifalar", "Aloqadan chiqqan hisoblagichlar jadvali"),
    ("view.obxod", "Sahifalar", "48 soat obxod jadvali"),
    ("map.view", "Sahifalar", "Xarita sahifasi"),
    ("brigade.view", "Sahifalar", "Brigadalar sahifasi"),
    ("settings.manage", "Sahifalar", "Sozlamalar sahifasi (Telegram bot va kanallar)"),
    ("drill.view", "Amallar", "Raqam ustiga bosib nomma-nom ro'yxatni ko'rish"),
    ("export", "Amallar", "Ro'yxatni Excel'ga yuklab olish"),
    ("dynamics.compare", "Amallar", "Dinamika sanalarini o'zgartirib solishtirish"),
    ("brigade.edit", "Amallar", "Brigada nomi va xodimlarini tahrirlash"),
    ("brigade.assign", "Amallar", "TP'larni brigadaga biriktirish / ko'chirish"),
    ("report.download", "Amallar", "Dinamikani Excel / PDF ko'rinishida yuklab olish"),
    ("telegram.send", "Amallar", "Hisobot va xabarlarni Telegram kanallarga yuborish"),
    ("data.upload", "Amallar", "Ma'lumot fayllarini yuklash"),
]
PERM_CODES = {p[0] for p in PERMS}
