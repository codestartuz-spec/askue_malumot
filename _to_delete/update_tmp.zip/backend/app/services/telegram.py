"""Telegram bot: yuborish va /start, /parol buyruqlari hamda kanal/guruhlarni avtomatik aniqlash (long polling)."""
import secrets
import threading
import time
import traceback
from datetime import datetime

import requests
from sqlalchemy import text

from ..config import settings
from ..db import engine
from ..security import hash_password


class TgError(Exception):
    pass


_sess = requests.Session()


def _proxies() -> dict | None:
    p = settings.telegram_proxy.strip()
    return {"http": p, "https": p} if p else None


def get_token() -> str:
    with engine.connect() as c:
        return c.execute(text("SELECT v FROM kv WHERE k='tg_token'")).scalar() or ""


def call(method: str, params: dict | None = None, files: dict | None = None,
         timeout: int = 30, token: str | None = None) -> dict:
    token = token if token is not None else get_token()
    if not token:
        raise TgError("Telegram bot tokeni kiritilmagan")
    try:
        r = _sess.post(f"{settings.telegram_api}/bot{token}/{method}", data=params or {}, files=files,
                       timeout=timeout, proxies=_proxies())
    except requests.RequestException as e:
        raise TgError(f"Telegram'ga ulanib bo'lmadi: {type(e).__name__}") from e
    try:
        j = r.json()
    except ValueError as e:
        raise TgError(f"Telegram javobi noto'g'ri ({r.status_code})") from e
    if not j.get("ok"):
        raise TgError(j.get("description") or f"Telegram xatosi ({r.status_code})")
    return j["result"]


def send_text(chat_id: str, msg: str, **kw) -> dict:
    return call("sendMessage", {"chat_id": chat_id, "text": msg[:4096], **kw})


def send_file(chat_id: str, filename: str, data: bytes, caption: str = "") -> dict:
    return call("sendDocument", {"chat_id": chat_id, "caption": caption[:1000]},
                files={"document": (filename, data)}, timeout=120)


def chat_kind(t: str) -> str:
    return {"channel": "kanal", "group": "guruh", "supergroup": "guruh"}.get(t, t)


def upsert_chat(chat: dict, source: str = "auto", active: bool = True) -> None:
    if chat.get("type") not in ("channel", "group", "supergroup"):
        return
    with engine.begin() as c:
        c.execute(text(
            "INSERT INTO tg_chats (chat_id,title,kind,username,source,is_active,created_at) "
            "VALUES (:i,:t,:k,:u,:s,:a,:n) ON DUPLICATE KEY UPDATE title=VALUES(title), kind=VALUES(kind), "
            "username=VALUES(username), is_active=VALUES(is_active)"),
            {"i": str(chat["id"]), "t": (chat.get("title") or "")[:200], "k": chat_kind(chat["type"]),
             "u": chat.get("username"), "s": source, "a": active, "n": datetime.now()})


# ---------------------------------------------------------------- bot buyruqlari
def _handle_message(m: dict) -> None:
    chat = m.get("chat", {})
    cid = str(chat.get("id"))
    txt = (m.get("text") or "").strip()
    if chat.get("type") != "private":
        if chat.get("type") in ("group", "supergroup"):
            upsert_chat(chat)
        return
    frm = m.get("from", {})
    name = " ".join(x for x in (frm.get("first_name"), frm.get("last_name")) if x)
    with engine.begin() as c:
        c.execute(text("INSERT INTO tg_users (chat_id,name,username,last_seen) VALUES (:i,:n,:u,:t) "
                       "ON DUPLICATE KEY UPDATE name=VALUES(name), username=VALUES(username), "
                       "last_seen=VALUES(last_seen)"),
                  {"i": cid, "n": name[:200], "u": frm.get("username"), "t": datetime.now()})
        user = c.execute(text("SELECT id, username, full_name FROM users WHERE chat_id=:i AND is_active=1"),
                         {"i": cid}).mappings().first()
    cmd = txt.split()[0].split("@")[0].lower() if txt.startswith("/") else ""
    if cmd in ("/start", "/id"):
        msg = (f"Assalomu alaykum{', ' + name if name else ''}!\n\n"
               f"Sizning Telegram chat ID raqamingiz:\n{cid}\n\n"
               "Shu raqamni ASKUE ma'lumot tizimida xodim profiliga kiriting — shunda parolni "
               "shu bot orqali tiklay olasiz.")
        if user:
            msg += f"\n\n✅ Siz tizimda «{user['username']}» ({user['full_name'] or '—'}) sifatida bog'langansiz."
        send_text(cid, msg)
    elif cmd in ("/parol", "/password"):
        if not user:
            send_text(cid, "Bu chat ID hech bir xodimga bog'lanmagan. Avval chat ID'ni tizimda profilingizga "
                           f"kiriting.\n\nChat ID: {cid}")
            return
        pw = secrets.token_urlsafe(8)
        with engine.begin() as c:
            c.execute(text("UPDATE users SET password_hash=:h WHERE id=:i"),
                      {"h": hash_password(pw), "i": user["id"]})
            c.execute(text("INSERT INTO audit (username,action,detail,created_at) VALUES (:u,'parol_tiklash',"
                           "'Telegram bot orqali yangi parol berildi',:t)"), {"u": user["username"], "t": datetime.now()})
        send_text(cid, f"🔑 Yangi parol: {pw}\nLogin: {user['username']}\n\nKirgach, parolni almashtirib qo'ying.")
    else:
        send_text(cid, "Buyruqlar:\n/start — chat ID'ni bilish\n/parol — yangi parol olish (xodim bo'lsangiz)")


def _handle_update(u: dict) -> None:
    if "message" in u:
        _handle_message(u["message"])
    elif "channel_post" in u:
        upsert_chat(u["channel_post"]["chat"])
    elif "my_chat_member" in u:
        e = u["my_chat_member"]
        status = e.get("new_chat_member", {}).get("status")
        if e["chat"].get("type") in ("channel", "group", "supergroup"):
            upsert_chat(e["chat"], active=status in ("administrator", "member"))


def poll_forever() -> None:
    offset = 0
    last_token = None
    while True:
        try:
            token = get_token()
            if not token:
                time.sleep(5)
                continue
            if token != last_token:
                last_token = token
                try:
                    call("deleteWebhook", token=token, timeout=15)
                except TgError:
                    pass
            updates = call("getUpdates", {"offset": offset, "timeout": 20,
                                          "allowed_updates": '["message","my_chat_member","channel_post"]'},
                           timeout=35, token=token)
            with engine.begin() as c:
                c.execute(text("INSERT INTO kv (k,v) VALUES ('tg_poll_hb',:v) ON DUPLICATE KEY UPDATE v=VALUES(v)"),
                          {"v": str(int(time.time()))})
            for u in updates:
                offset = u["update_id"] + 1
                try:
                    _handle_update(u)
                except Exception:  # noqa: BLE001
                    traceback.print_exc()
        except TgError as e:
            print(f"Telegram: {e}", flush=True)
            time.sleep(8)
        except Exception:  # noqa: BLE001
            traceback.print_exc()
            time.sleep(8)


def start_polling() -> None:
    threading.Thread(target=poll_forever, daemon=True, name="tg-poll").start()
