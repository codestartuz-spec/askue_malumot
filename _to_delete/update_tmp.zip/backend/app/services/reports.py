"""Dinamika hisobotlari: Excel va PDF."""
import io
from datetime import date

import xlsxwriter
from reportlab.lib import colors
from reportlab.lib.pagesizes import A3, landscape
from reportlab.lib.styles import ParagraphStyle
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

from ..config import BASE
from . import report_spec as S

_FONTS = BASE / "assets" / "fonts"
_registered = False


def _fonts() -> None:
    global _registered
    if not _registered:
        pdfmetrics.registerFont(TTFont("DV", str(_FONTS / "DejaVuSans.ttf")))
        pdfmetrics.registerFont(TTFont("DV-B", str(_FONTS / "DejaVuSans-Bold.ttf")))
        pdfmetrics.registerFontFamily("DV", normal="DV", bold="DV-B")
        _registered = True


def dmy(iso: str | None) -> str:
    return ".".join(reversed(iso.split("-"))) if iso else ""


def period(data: dict) -> str:
    if data.get("base"):
        return f"{dmy(data['base'])} – {dmy(data['to'])}"
    return dmy(data.get("to"))


def title_of(table: str, scope: str) -> str:
    return f"{scope} {S.TABLES[table]['title']}"


def _body_rows(data: dict):
    """[(nom, cur, base, is_total)] — birinchi qator 'Jami'."""
    tot = data["total"]
    rows = [("Jami", tot["cur"], tot["base"], True)]
    rows += [(r["name"], r["cur"], r["base"], False) for r in data["rows"]]
    return rows


# --------------------------------------------------------------------- Excel
def build_xlsx(items: list[tuple[str, dict]], scope: str, first_col: str) -> bytes:
    buf = io.BytesIO()
    wb = xlsxwriter.Workbook(buf, {"in_memory": True})
    fcache: dict = {}

    def fmt(**kw):
        key = tuple(sorted(kw.items()))
        if key not in fcache:
            fcache[key] = wb.add_format({"font_name": "Calibri", "font_size": 10, "valign": "vcenter", **kw})
        return fcache[key]

    for table, data in items:
        cfg = S.TABLES[table]
        ws = wb.add_worksheet(cfg["short"][:30])
        ncols = 1 + len(cfg["cols"])
        ws.merge_range(0, 0, 0, ncols - 1, title_of(table, scope), fmt(bold=True, font_size=14, align="center",
                                                                       font_color="#0B3B8C"))
        ws.merge_range(1, 0, 1, ncols - 1, f"D I N A M I K A     {period(data)}",
                       fmt(bold=True, align="center", font_color="#E31E24"))
        top = 3
        heads = [[(l if l != "Hudud nomi" else first_col, rs, cs, c) for (l, rs, cs, c) in row]
                 for row in cfg["head"]]
        for r, c, rs, cs, label, cls in S.place_header(heads, ncols):
            f = fmt(bold=True, font_color="#FFFFFF", bg_color=S.HEAD_BG.get(cls.split()[0] if cls else "", "#0B3B8C"),
                    align="center", text_wrap=True, border=1)
            if rs == 1 and cs == 1:
                ws.write(top + r, c, label, f)
            else:
                ws.merge_range(top + r, c, top + r + rs - 1, c + cs - 1, label, f)
        start = top + len(cfg["head"])
        for i, (name, cur, base, total) in enumerate(_body_rows(data)):
            bg = "#E8EEF9" if total else ("#F7F9FC" if i % 2 == 0 else "#FFFFFF")
            ws.write(start + i, 0, name, fmt(bold=True, bg_color=bg, border=1, align="left"))
            for j, col in enumerate(cfg["cols"], start=1):
                txt, color, bold = S.cell_values(col, cur, base)
                kw = dict(bg_color=bg, border=1, align="center", bold=bold or total)
                if color:
                    kw["font_color"] = S.COLORS.get(color, "#111827")
                if col[0] == "n" and txt:
                    ws.write_number(start + i, j, int(cur.get(col[1], 0)), fmt(**kw, num_format="#,##0"))
                else:
                    ws.write(start + i, j, txt, fmt(**kw))
        ws.set_column(0, 0, 24)
        ws.set_column(1, ncols - 1, 12)
        for r in range(len(cfg["head"])):
            ws.set_row(top + r, 34)
        ws.freeze_panes(start, 1)
        ws.set_landscape()
        ws.fit_to_pages(1, 0)
        ws.set_paper(8)
    wb.close()
    return buf.getvalue()


# ----------------------------------------------------------------------- PDF
def build_pdf(items: list[tuple[str, dict]], scope: str, first_col: str) -> bytes:
    _fonts()
    buf = io.BytesIO()
    page = landscape(A3)
    doc = SimpleDocTemplate(buf, pagesize=page, leftMargin=14 * mm, rightMargin=14 * mm, topMargin=12 * mm,
                            bottomMargin=12 * mm, title="ASKUE ma'lumot — dinamika", author="ASKUE ma'lumot")
    ttl = ParagraphStyle("t", fontName="DV-B", fontSize=17, leading=21, alignment=1, textColor=colors.HexColor("#0B3B8C"))
    sub = ParagraphStyle("s", fontName="DV-B", fontSize=12, leading=16, alignment=1, textColor=colors.HexColor("#E31E24"))
    note = ParagraphStyle("n", fontName="DV", fontSize=8, leading=10, textColor=colors.HexColor("#64748B"))
    story = []
    avail = page[0] - 28 * mm
    for k, (table, data) in enumerate(items):
        if k:
            story.append(PageBreak())
        cfg = S.TABLES[table]
        ncols = 1 + len(cfg["cols"])
        story += [Paragraph(title_of(table, scope), ttl), Spacer(1, 3 * mm),
                  Paragraph("D I N A M I K A &nbsp;&nbsp;&nbsp; " + period(data), sub), Spacer(1, 5 * mm)]
        heads = [[(l if l != "Hudud nomi" else first_col, rs, cs, c) for (l, rs, cs, c) in row] for row in cfg["head"]]
        nh = len(heads)
        grid = [[""] * ncols for _ in range(nh)]
        style = [("FONTNAME", (0, 0), (-1, -1), "DV"), ("FONTSIZE", (0, 0), (-1, -1), 8),
                 ("ALIGN", (0, 0), (-1, -1), "CENTER"), ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
                 ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#9AA9C4")),
                 ("TOPPADDING", (0, 0), (-1, -1), 3), ("BOTTOMPADDING", (0, 0), (-1, -1), 3),
                 ("LEFTPADDING", (0, 0), (-1, -1), 2), ("RIGHTPADDING", (0, 0), (-1, -1), 2)]
        hs = ParagraphStyle("h", fontName="DV-B", fontSize=7.5, leading=9, alignment=1, textColor=colors.white)
        for r, c, rs, cs, label, cls in S.place_header(heads, ncols):
            grid[r][c] = Paragraph(label, hs)
            bg = colors.HexColor(S.HEAD_BG.get(cls.split()[0] if cls else "", "#0B3B8C"))
            style.append(("BACKGROUND", (c, r), (c + cs - 1, r + rs - 1), bg))
            if rs > 1 or cs > 1:
                style.append(("SPAN", (c, r), (c + cs - 1, r + rs - 1)))
        for i, (name, cur, base, total) in enumerate(_body_rows(data)):
            r = nh + i
            row = [name]
            for j, col in enumerate(cfg["cols"], start=1):
                txt, color, bold = S.cell_values(col, cur, base)
                row.append(txt)
                if color:
                    style.append(("TEXTCOLOR", (j, r), (j, r), colors.HexColor(S.COLORS.get(color, "#111827"))))
                if bold or total:
                    style.append(("FONTNAME", (j, r), (j, r), "DV-B"))
            grid.append(row)
            style.append(("ALIGN", (0, r), (0, r), "LEFT"))
            style.append(("FONTNAME", (0, r), (0, r), "DV-B"))
            style.append(("BACKGROUND", (0, r), (-1, r), colors.HexColor("#E3EAF8") if total else
                          (colors.HexColor("#F6F8FC") if i % 2 == 0 else colors.white)))
        name_w = 36 * mm
        w = (avail - name_w) / (ncols - 1)
        t = Table(grid, colWidths=[name_w] + [w] * (ncols - 1), rowHeights=[11 * mm] * nh + [7 * mm] * (len(grid) - nh),
                  repeatRows=nh)
        t.setStyle(TableStyle(style))
        story += [t, Spacer(1, 4 * mm), Paragraph(f"Hisobot sanasi: {date.today():%d.%m.%Y} • ASKUE ma'lumot", note)]
    doc.build(story)
    return buf.getvalue()
