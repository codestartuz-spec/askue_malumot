import time

from fastapi import APIRouter, Depends, HTTPException
from pydantic import BaseModel
from sqlalchemy import text
from sqlalchemy.orm import Session

from ..db import get_db
from ..deps import log, need, need_any, sadmin_only
from ..models import User
from ..services import telegram as tg

router = APIRouter(prefix="/telegram", tags=["telegram"])


def _mask(t: str) -> str:
    return f"{t.split(':')[0]}:{'•' * 10}{t[-4:]}" if t else ""


def _kv(db: Session, k: str) -> str:
    return db.execute(text("SELECT v FROM kv WHERE k=:k"), {"k": k}).scalar() or ""


def _set_kv(db: Session, k: str, v: str) -> None:
    db.execute(text("INSERT INTO kv (k,v) VALUES (:k,:v) ON DUPLICATE KEY UPDATE v=VALUES(v)"), {"k": k, "v": v})


def _chats(db: Session, only_active: bool) -> list[dict]:
    q = "SELECT id, chat_id, title, kind, username, source, is_active FROM tg_chats"
    if only_active:
        q += " WHERE is_active=1"
    return [dict(r) for r in db.execute(text(q + " ORDER BY kind, title")).mappings()]


@router.get("")
def overview(_: User = Depends(need_any("settings.manage")), db: Session = Depends(get_db)):
    token = _kv(db, "tg_token")
    hb = _kv(db, "tg_poll_hb")
    return {"configured": bool(token), "token": _mask(token), "bot_username": _kv(db, "tg_bot_username"),
            "bot_name": _kv(db, "tg_bot_name"), "poll_alive": bool(hb and time.time() - int(hb) < 60),
            "chats": _chats(db, False)}


class TokenIn(BaseModel):
    token: str


@router.put("/token")
def set_token(body: TokenIn, me: User = Depends(sadmin_only), db: Session = Depends(get_db)):
    token = body.token.strip()
    try:
        bot = tg.call("getMe", token=token, timeout=20)
    except tg.TgError as e:
        raise HTTPException(400, f"Token tekshiruvdan o'tmadi: {e}") from e
    _set_kv(db, "tg_token", token)
    _set_kv(db, "tg_bot_username", bot.get("username", ""))
    _set_kv(db, "tg_bot_name", bot.get("first_name", ""))
    log(db, me.username, "telegram_token", f"Bot ulandi: @{bot.get('username')}")
    db.commit()
    return {"ok": True, "bot_username": bot.get("username"), "bot_name": bot.get("first_name")}


@router.delete("/token")
def del_token(me: User = Depends(sadmin_only), db: Session = Depends(get_db)):
    for k in ("tg_token", "tg_bot_username", "tg_bot_name", "tg_poll_hb"):
        db.execute(text("DELETE FROM kv WHERE k=:k"), {"k": k})
    log(db, me.username, "telegram_token", "Bot uzildi")
    db.commit()
    return {"ok": True}


class ChatIn(BaseModel):
    chat: str      # raqamli ID (-100...) yoki @kanal_nomi


@router.post("/chats")
def add_chat(body: ChatIn, me: User = Depends(need("settings.manage")), db: Session = Depends(get_db)):
    ref = body.chat.strip()
    if ref and not ref.startswith("@") and not ref.lstrip("-").isdigit():
        ref = "@" + ref.split("/")[-1]
    try:
        chat = tg.call("getChat", {"chat_id": ref}, timeout=20)
    except tg.TgError as e:
        raise HTTPException(400, f"Kanal topilmadi: {e}. Bot kanalga admin qilib qo'shilganini tekshiring") from e
    if chat.get("type") not in ("channel", "group", "supergroup"):
        raise HTTPException(400, "Bu kanal yoki guruh emas")
    warn = ""
    try:
        bot_id = tg.call("getMe", timeout=15)["id"]
        st = tg.call("getChatMember", {"chat_id": chat["id"], "user_id": bot_id}, timeout=15).get("status")
        if st not in ("administrator", "creator"):
            warn = "Diqqat: bot bu yerda admin emas — xabar yuborolmasligi mumkin"
    except tg.TgError:
        warn = "Botning huquqlarini tekshirib bo'lmadi"
    tg.upsert_chat(chat, source="manual")
    log(db, me.username, "telegram_kanal", f"Qo'shildi: {chat.get('title')} ({chat['id']})")
    db.commit()
    return {"ok": True, "title": chat.get("title"), "warning": warn}


@router.delete("/chats/{cid}")
def del_chat(cid: int, me: User = Depends(need("settings.manage")), db: Session = Depends(get_db)):
    db.execute(text("DELETE FROM tg_chats WHERE id=:i"), {"i": cid})
    log(db, me.username, "telegram_kanal", f"O'chirildi #{cid}")
    db.commit()
    return {"ok": True}


@router.get("/chats")
def active_chats(_: User = Depends(need_any("telegram.send", "settings.manage")), db: Session = Depends(get_db)):
    return _chats(db, True)


@router.get("/starters")
def starters(_: User = Depends(sadmin_only), db: Session = Depends(get_db)):
    """Botga /start bosganlar: xodim profiliga chat ID kiritishda tanlash uchun."""
    return [dict(r) | {"last_seen": r["last_seen"].isoformat()} for r in db.execute(text(
        "SELECT chat_id, name, username, last_seen FROM tg_users ORDER BY last_seen DESC LIMIT 100")).mappings()]


class SendIn(BaseModel):
    chat_ids: list[int]
    message: str


@router.post("/send")
def send_message(body: SendIn, me: User = Depends(need("telegram.send")), db: Session = Depends(get_db)):
    if not body.message.strip():
        raise HTTPException(400, "Xabar matnini kiriting")
    if not body.chat_ids:
        raise HTTPException(400, "Kamida bitta kanal yoki guruhni tanlang")
    rows = db.execute(text("SELECT chat_id, title FROM tg_chats WHERE id IN :ids").bindparams(
        __import__("sqlalchemy").bindparam("ids", expanding=True)), {"ids": body.chat_ids}).all()
    ok, fail = [], []
    for chat_id, title in rows:
        try:
            tg.send_text(chat_id, body.message.strip())
            ok.append(title)
        except tg.TgError as e:
            fail.append(f"{title}: {e}")
    log(db, me.username, "telegram_xabar", f"→ {', '.join(ok) or '—'}" + (f"; xato: {fail}" if fail else ""))
    db.commit()
    return {"sent": ok, "failed": fail}
