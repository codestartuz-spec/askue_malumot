import { useEffect, useState } from 'react'
import { Bot, Megaphone, Users, Plus, Trash2, Send, CheckCircle2, AlertTriangle, PlugZap, Unplug, KeyRound, BookOpen, RefreshCw, ShieldAlert } from 'lucide-react'
import { api } from '../api'
import { useAuth } from '../auth'
import { Spinner, useToast } from '../ui'

export default function Settings() {
  const { user, can } = useAuth()
  const toast = useToast()
  const [d, setD] = useState(null)
  const [token, setToken] = useState('')
  const [chat, setChat] = useState('')
  const [msg, setMsg] = useState('')
  const [sel, setSel] = useState(new Set())
  const [busy, setBusy] = useState('')
  const load = () => api.get('/telegram').then(setD).catch((e) => toast(e.message, 'err'))
  useEffect(() => { load(); const t = setInterval(load, 15000); return () => clearInterval(t) }, [])
  const run = async (name, fn, ok) => {
    setBusy(name)
    try { const r = await fn(); if (ok) toast(typeof ok === 'function' ? ok(r) : ok); await load(); return r }
    catch (e) { toast(e.message, 'err') } finally { setBusy('') }
  }
  const saveToken = () => run('token', () => api.put('/telegram/token', { token }), (r) => `Bot ulandi: @${r.bot_username}`).then(() => setToken(''))
  const addChat = () => run('chat', async () => { const r = await api.post('/telegram/chats', { chat }); setChat(''); if (r.warning) toast(r.warning, 'err'); return r }, (r) => `Qo'shildi: ${r.title}`)
  const delChat = (c) => confirm(`«${c.title}» ro'yxatdan olib tashlansinmi?`) && run('del' + c.id, () => api.del(`/telegram/chats/${c.id}`), "O'chirildi")
  const send = () => run('send', () => api.post('/telegram/send', { chat_ids: [...sel], message: msg }),
    (r) => (r.failed.length ? `Yuborildi: ${r.sent.length}, xato: ${r.failed.length}` : `Yuborildi: ${r.sent.length} ta`)).then((r) => {
    if (r?.failed?.length) toast(r.failed.join('; '), 'err')
    if (r && !r.failed.length) setMsg('')
  })
  const toggle = (id) => setSel((s) => { const n = new Set(s); n.has(id) ? n.delete(id) : n.add(id); return n })
  const active = (d?.chats || []).filter((c) => c.is_active)

  if (!d) return <Spinner />
  return (
    <div className="settings">
      <div className="card head-card">
        <div className="titles"><h2 className="ttl">Sozlamalar</h2>
          <p className="sub">Telegram bot, kanal va guruhlar. Hisobotlar va xabarlar shu bot orqali yuboriladi, parol esa chat ID orqali tiklanadi.</p></div>
      </div>

      <div className="set-grid">
        <section className="card pad set-card">
          <h3><Bot size={20} />Telegram bot</h3>
          <div className={`bot-state ${d.configured ? 'ok' : 'off'}`}>
            {d.configured ? <><PlugZap size={20} /><div><b>@{d.bot_username}</b><small>{d.bot_name} • token: {d.token}</small></div></> : <><Unplug size={20} /><div><b>Bot ulanmagan</b><small>Token kiritib ulang</small></div></>}
            {d.configured && <span className={`tag ${d.poll_alive ? 'green' : 'amber'}`}>{d.poll_alive ? 'Bot javob bermoqda' : 'Worker kutilmoqda'}</span>}
          </div>
          {user.is_super ? (
            <>
              <label className="field"><span><KeyRound size={14} />Bot tokeni (@BotFather beradi)</span>
                <input value={token} onChange={(e) => setToken(e.target.value)} placeholder="123456789:AA..." autoComplete="off" /></label>
              <div className="row-btns">
                <button className="btn primary" disabled={!token.trim() || busy === 'token'} onClick={saveToken}><PlugZap size={16} />{d.configured ? 'Tokenni almashtirish' : 'Ulash'}</button>
                {d.configured && <button className="btn ghost" onClick={() => confirm('Bot uzilsinmi?') && run('un', () => api.del('/telegram/token'), 'Bot uzildi')}><Unplug size={16} />Uzish</button>}
              </div>
            </>) : <p className="hint">Tokenni faqat sadmin o'zgartira oladi.</p>}
          <div className="howto"><BookOpen size={16} /><div>
            <b>Qanday ulanadi?</b>
            <ol>
              <li>Telegram'da <b>@BotFather</b> orqali bot yarating va tokenni shu yerga kiriting.</li>
              <li>Botni kerakli <b>kanal yoki guruhga admin</b> qilib qo'shing (kanalda «Xabar yuborish» huquqi bilan).</li>
              <li>Bot qo'shilgach kanal/guruh quyidagi ro'yxatda o'zi paydo bo'ladi. Paydo bo'lmasa, chat ID yoki <code>@nom</code> orqali qo'lda qo'shing.</li>
              <li>Xodimlar botga <b>/start</b> bosib chat ID'sini oladi va profiliga kiritadi — parolni shu orqali tiklaydi.</li>
            </ol></div></div>
        </section>

        <section className="card pad set-card">
          <h3><Megaphone size={20} />Kanal va guruhlar <button className="icon-btn" title="Yangilash" onClick={load}><RefreshCw size={16} /></button></h3>
          {d.chats.length === 0 ? <div className="empty sm"><Megaphone size={28} /><div>Hali kanal yoki guruh yo'q</div></div> : (
            <div className="chat-list">{d.chats.map((c) => (
              <div key={c.id} className={`chat static ${c.is_active ? '' : 'off'}`}>
                <i>{c.kind === 'kanal' ? <Megaphone size={18} /> : <Users size={18} />}</i>
                <span><b>{c.title}</b><small>{c.kind}{c.username ? ` • @${c.username}` : ''} • {c.source === 'auto' ? 'avtomatik aniqlangan' : "qo'lda qo'shilgan"} • <span className="mono">{c.chat_id}</span>{!c.is_active ? " • bot chiqarib yuborilgan" : ''}</small></span>
                {can('settings.manage') && <button className="icon-btn danger" onClick={() => delChat(c)} title="Olib tashlash"><Trash2 size={17} /></button>}
              </div>))}</div>)}
          {d.configured && can('settings.manage') && (
            <div className="add-chat">
              <input value={chat} onChange={(e) => setChat(e.target.value)} placeholder="@kanal_nomi yoki -100123456789" onKeyDown={(e) => e.key === 'Enter' && chat.trim() && addChat()} />
              <button className="btn primary" disabled={!chat.trim() || busy === 'chat'} onClick={addChat}><Plus size={16} />Qo'shish</button>
            </div>)}
          {!d.configured && <p className="hint warn-hint"><ShieldAlert size={14} /> Avval botni ulang.</p>}
        </section>

        {can('telegram.send') && (
          <section className="card pad set-card wide">
            <h3><Send size={20} />Xabar yuborish</h3>
            {active.length === 0 ? <p className="hint">Xabar yuborish uchun kamida bitta kanal yoki guruh bo'lishi kerak.</p> : (
              <>
                <div className="mp-sec dark">Qaysi kanal / guruhga</div>
                <div className="pick-chats">{active.map((c) => (
                  <label key={c.id} className={`chat sm ${sel.has(c.id) ? 'on' : ''}`}><input type="checkbox" checked={sel.has(c.id)} onChange={() => toggle(c.id)} />
                    <i>{c.kind === 'kanal' ? <Megaphone size={16} /> : <Users size={16} />}</i><span><b>{c.title}</b></span></label>))}</div>
                <label className="field"><span>Xabar matni</span><textarea rows={4} value={msg} onChange={(e) => setMsg(e.target.value)} placeholder="Xabarni yozing…" maxLength={4000} /></label>
                <div className="row-btns"><button className="btn primary" disabled={!msg.trim() || !sel.size || busy === 'send'} onClick={send}><Send size={16} />Yuborish ({sel.size})</button>
                  <span className="hint">Hisobot fayllarini «Dinamika» sahifasidagi «Telegramga yuborish» tugmasi orqali yuborasiz.</span></div>
              </>)}
          </section>)}
      </div>
    </div>
  )
}
