// Xarita belgilari (inline SVG): hisoblagich (aholi / ulgurji / balans) va konsentrator
import L from 'leaflet'

export const STATUS_COLOR = { ok: '#16a34a', warn: '#f59e0b', bad: '#e11d2e', none: '#7b8aa3' }
export const bucketStatus = (b) => (b === 1 ? 'ok' : b === 2 ? 'warn' : b >= 3 ? 'bad' : 'none')
export const trStatus = (s) => (s === 1 ? 'ok' : s === 2 ? 'bad' : 'none')

const G = {
  aholi: '<path d="M15 21v-8a1 1 0 0 0-1-1h-4a1 1 0 0 0-1 1v8"/><path d="M3 10a2 2 0 0 1 .709-1.528l7-5.999a2 2 0 0 1 2.582 0l7 5.999A2 2 0 0 1 21 10v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>',
  ulgurji: '<path d="M2 20a2 2 0 0 0 2 2h16a2 2 0 0 0 2-2V8l-7 5V8l-7 5V4a2 2 0 0 0-2-2H4a2 2 0 0 0-2 2Z"/>',
  balans: '<path d="M12 3v18"/><path d="M5 21h14"/><path d="M5 7h14"/><path d="m5 7-3 7a3 3 0 0 0 6 0z"/><path d="m19 7-3 7a3 3 0 0 0 6 0z"/>',
  tr: '<path d="M4.9 19.1C1 15.2 1 8.8 4.9 4.9"/><path d="M7.8 16.2c-2.3-2.3-2.3-6.1 0-8.5"/><circle cx="12" cy="12" r="2"/><path d="M16.2 7.8c2.3 2.3 2.3 6.1 0 8.5"/><path d="M19.1 4.9C23 8.8 23 15.1 19.1 19.1"/>',
}
export const KIND_NAME = { aholi: 'Aholi hisoblagichi', ulgurji: 'Ulgurji hisoblagich', balans: 'Balans hisoblagich', tr: 'Konsentrator (TP)' }
export const glyph = (kind, size = 18, color = '#fff') =>
  `<svg width="${size}" height="${size}" viewBox="0 0 24 24" fill="none" stroke="${color}" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">${G[kind]}</svg>`

export function pinIcon(kind, status, { big = false, focus = false } = {}) {
  const color = STATUS_COLOR[status]
  const w = big ? 40 : 32, h = big ? 52 : 42
  const ring = kind === 'tr' ? '#0b2a6b' : '#ffffff'
  const html = `
    <div class="pin ${focus ? 'pin-focus' : ''} ${status === 'bad' ? 'pin-bad' : ''}" style="width:${w}px;height:${h}px">
      <svg viewBox="0 0 32 42" width="${w}" height="${h}">
        <ellipse cx="16" cy="40" rx="6" ry="2" fill="rgba(0,0,0,.28)"/>
        <path d="M16 40C16 40 3 26 3 15a13 13 0 0 1 26 0c0 11-13 25-13 25z" fill="${color}" stroke="${ring}" stroke-width="${kind === 'tr' ? 2.6 : 2}"/>
        ${kind === 'tr' ? '<circle cx="16" cy="15" r="9.8" fill="#0b2a6b"/>' : '<circle cx="16" cy="15" r="9.4" fill="rgba(0,0,0,.16)"/>'}
      </svg>
      <span class="pin-g" style="top:${big ? 9 : 6}px">${glyph(kind, big ? 20 : 17)}</span>
    </div>`
  return L.divIcon({ html, className: 'pin-wrap', iconSize: [w, h], iconAnchor: [w / 2, h - 2], tooltipAnchor: [0, -h + 8] })
}

const compact = (n) => (n >= 10000 ? `${Math.round(n / 1000)}k` : n >= 1000 ? `${(n / 1000).toFixed(1).replace('.0', '')}k` : String(n))
export function clusterIcon(c) {
  const size = Math.round(Math.min(64, 30 + Math.log10(c.n + 1) * 9) * (c.t === 't' ? 0.82 : 1))
  let cls = 'cl-tr'
  if (c.t === 'm') {
    const r = c.n ? c.bad / c.n : 0
    cls = r > 0.4 ? 'cl-bad' : r > 0.12 ? 'cl-warn' : 'cl-ok'
  }
  const ico = c.t === 't' ? `<i>${glyph('tr', 12)}</i>` : ''
  return L.divIcon({
    html: `<div class="cluster ${cls}" style="width:${size}px;height:${size}px"><b>${ico}${compact(c.n)}</b></div>`,
    className: 'cluster-wrap', iconSize: [size, size],
  })
}
