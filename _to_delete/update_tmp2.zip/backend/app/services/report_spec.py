"""Uch dinamika jadvalining tuzilishi (hisobotlar uchun). Frontend'dagi tables.js bilan bir xil."""
n = lambda m, cls="": ("n", m, cls)                    # noqa: E731
d = lambda m, pol: ("d", m, pol)                       # noqa: E731
p = lambda a, b: ("p", a, b)                           # noqa: E731
H = lambda label, rs=1, cs=1, c="": (label, rs, cs, c)  # noqa: E731

_ARR = H("↑↓", c="arr")

TABLES = {
    "konsentrator": {
        "title": "hududida CAS dasturida mavjud konsentratorlar holati bo'yicha",
        "short": "Konsentratorlar",
        "head": [
            [H("Hudud nomi", 3, 1), H("Dasturda mavjud transformatorlar soni", 3, 1, "vert"),
             H("Konsentratorlar", 1, 5), H("Konsentratorlarning obxod olish darajasi bo'yicha soni", 1, 10),
             H("Iste'molchi biriktirilmagan konsentratorlar soni", 3, 1, "vert red")],
            [H("CAS ga yuklangan", 2, 1, "vert"), H("shundan", 1, 4, "it"), H("0%", 1, 2), H("1-30%", 1, 2),
             H("30-50%", 1, 2), H("50-80%", 1, 2), H("80-100%", 1, 2)],
            [H("Online", c="green s"), H("Offline (jami)", c="red s"), H("shundan 3 kundan ortiq", c="red s"), _ARR]
            + [x for _ in range(5) for x in (H("soni", c="red s"), _ARR)],
        ],
        "cols": [n("tp_total", "b"), n("cas_loaded", "b"), n("online", "green"), n("offline", "red"),
                 n("offline3", "red"), d("offline", "bad"),
                 n("lv0", "red"), d("lv0", "bad"), n("lv1", "red"), d("lv1", "bad"), n("lv2", "red"), d("lv2", "bad"),
                 n("lv3", "red"), d("lv3", "mid"), n("lv4", "b"), d("lv4", "good"), n("unattached", "red")],
    },
    "aloqa": {
        "title": "hududida CAS dasturida aloqaga chiqmagan hisoblagichlar bo'yicha",
        "short": "Aloqadan chiqib ketgan hisoblagichlar",
        "head": [
            [H("Hudud nomi", 4, 1), H("Aloqaga chiqqan hisoblagichlar soni", 4, 1, "vert green"),
             H("Aloqaga chiqmay qolgan hisoblagichlar soni", 1, 17, "red"),
             H("Umuman aloqaga chiqmagan hisoblagichlar", 4, 1, "vert red"),
             H("To'g'ridan-to'g'ri ulanish (peremichka)", 3, 2, "purple")],
            [H("Jami", 1, 3), H("Iste'molchi turi kesimida", 1, 6, "it"), H("Vaqtlar kesimida", 1, 8, "it")],
            [H("soni", 2, 1, "red s"), H("%", 2, 1, "s"), H("↑↓", 2, 1, "arr"), H("Aholi", 1, 2, "green"),
             H("Ulgurji", 1, 2, "blue"), H("Balans", 1, 2, "amber"), H("2-7 kun", 1, 2), H("7-30 kun", 1, 2),
             H("1-3 oy", 1, 2), H("3 oydan ortiq", 1, 2)],
            [x for _ in range(8) for x in (H("soni", c="red s"), _ARR)],
        ],
        "cols": [n("m_conn", "green b"), n("out_total", "red b"), p("out_total", "m_total"), d("out_total", "bad"),
                 n("out_aholi", "b"), d("out_aholi", "bad"), n("out_ulgurji", "b"), d("out_ulgurji", "bad"),
                 n("out_balans", "amber"), d("out_balans", "bad"), n("out_2_7", "b"), d("out_2_7", "bad"),
                 n("out_7_30", "b"), d("out_7_30", "bad"), n("out_30_90", "b"), d("out_30_90", "bad"),
                 n("out_90p", "b"), d("out_90p", "bad"), n("m_nopoll", "red"),
                 n("m_direct", "purple b"), d("m_direct", "bad")],
    },
    "obxod": {
        "title": "hududida 48 soat ichida obxod bergan hisoblagichlar bo'yicha",
        "short": "48 soat obxod",
        "head": [
            [H("Hudud nomi", 3, 1), H("Jami hisoblagichlar", 2, 4), H("shundan", 1, 12, "it")],
            [H("Aholi iste'molchilari", 1, 4, "green"), H("Ulgurji iste'molchilar", 1, 4, "amber"),
             H("Balans hisoblagichlar", 1, 4, "purple")],
            [H("Jami soni", c="s"), H("shundan obxod olgan", c="green s"), H("%", c="s"), _ARR] * 4,
        ],
        "cols": [n("m_total", "b"), n("polled", "b"), p("polled", "m_total"), d("polled", "mid"),
                 n("a_total"), n("a_polled", "b"), p("a_polled", "a_total"), d("a_polled", "mid"),
                 n("u_total"), n("u_polled", "b"), p("u_polled", "u_total"), d("u_polled", "mid"),
                 n("b_total"), n("b_polled", "b"), p("b_polled", "b_total"), d("b_polled", "mid")],
    },
}

# pol: o'sish / kamayish ranglari
POL = {"bad": ("red", "blue"), "mid": ("blue", "red"), "good": ("green", "red")}
# Namuna (Excel) hisobotidagi ranglar: oq fon, qora chegara, och ko'k sarlavha, och sariq "Jami" qatori
COLORS = {"red": "#C00000", "green": "#00A050", "blue": "#0033CC", "amber": "#C55A11", "purple": "#7030A0",
          "": "#000000", "b": "#000000"}
ARROW = {"up_red": "#FF0000", "down_blue": "#0033CC"}
HEAD_BG = "#DCE6F1"
TOTAL_BG = "#FFE699"
HEAD_TXT = {"red": "#C00000", "green": "#00A050", "blue": "#2F5597", "amber": "#C55A11", "purple": "#7030A0",
            "": "#000000"}


def head_style(cls: str) -> dict:
    """Sarlavha katagi uslubi: matn rangi, vertikal, kursiv, kichik, strelka."""
    t = (cls or "").split()
    color = next((x for x in t if x in HEAD_TXT), "")
    return {"color": HEAD_TXT[color], "vert": "vert" in t, "it": "it" in t, "small": "s" in t, "arr": "arr" in t}


def place_header(rows: list[list[tuple]], ncols: int) -> list[tuple]:
    """HTML jadval kabi rowspan/colspan joylashtiradi. Qaytaradi: [(r, c, rs, cs, label, cls)]."""
    occupied: set[tuple[int, int]] = set()
    cells = []
    for r, row in enumerate(rows):
        c = 0
        for label, rs, cs, cls in row:
            while (r, c) in occupied:
                c += 1
            for i in range(rs):
                for j in range(cs):
                    occupied.add((r + i, c + j))
            cells.append((r, c, rs, cs, label, cls))
            c += cs
    return cells


def fmt_num(v) -> str:
    return "" if v is None else f"{int(round(v)):,}".replace(",", " ")


def cell_values(col: tuple, cur: dict, base: dict | None):
    """Qaytaradi: (matn, rang_nomi, qalin_mi)."""
    t = col[0]
    if t == "n":
        v = cur.get(col[1], 0)
        cls = col[2].split()
        color = next((x for x in cls if x in ("red", "green", "amber", "blue", "purple")), "")
        return (fmt_num(v) if v else "", color, True)
    if t == "p":
        a, b = cur.get(col[1], 0), cur.get(col[2], 0)
        return (f"{a / b * 100:.1f}%".replace(".", ",") if b > 0 else "", "", False)
    if base is None:
        return ("", "", False)
    dv = cur.get(col[1], 0) - base.get(col[1], 0)
    if dv == 0:
        return ("", "", False)
    up, down = POL[col[2]]
    return (("↑" if dv > 0 else "↓") + str(abs(dv)), up if dv > 0 else down, True)
